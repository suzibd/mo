// 지역별 숙소 데이터
const accommodationData = {
    '서울': [
        { name: '롯데호텔 서울', type: '호텔', price: '₩200,000~', rating: '★★★★★', location: '명동', description: '명동 중심가에 위치한 럭셔리 호텔' },
        { name: '신라호텔', type: '호텔', price: '₩250,000~', rating: '★★★★★', location: '장충동', description: '한국 전통과 현대가 어우러진 프리미엄 호텔' },
        { name: '그랜드 하얏트 서울', type: '호텔', price: '₩180,000~', rating: '★★★★★', location: '용산', description: '한강 전망이 아름다운 호텔' },
        { name: '홍대 게스트하우스', type: '게스트하우스', price: '₩30,000~', rating: '★★★☆☆', location: '홍대', description: '젊은 감성의 게스트하우스' },
        { name: '명동 호스텔', type: '호스텔', price: '₩25,000~', rating: '★★★☆☆', location: '명동', description: '저렴하고 편리한 위치의 호스텔' }
    ],
    '경기도': [
        { name: '에버랜드 리조트', type: '리조트', price: '₩150,000~', rating: '★★★★☆', location: '용인', description: '에버랜드와 함께 즐기는 리조트' },
        { name: '수원화성 근처 펜션', type: '펜션', price: '₩80,000~', rating: '★★★☆☆', location: '수원', description: '수원화성 인근 조용한 펜션' },
        { name: '가평 쁘띠프랑스 호텔', type: '호텔', price: '₩120,000~', rating: '★★★★☆', location: '가평', description: '프랑스 테마의 아늑한 호텔' },
        { name: '파주 헤이리 게스트하우스', type: '게스트하우스', price: '₩40,000~', rating: '★★★☆☆', location: '파주', description: '예술가 마을 근처 게스트하우스' }
    ],
    '강원도': [
        { name: '설악산 리조트', type: '리조트', price: '₩180,000~', rating: '★★★★☆', location: '속초', description: '설악산 전망이 아름다운 리조트' },
        { name: '남이섬 펜션', type: '펜션', price: '₩100,000~', rating: '★★★★☆', location: '춘천', description: '자연 속에서 즐기는 펜션' },
        { name: '강릉 안목해변 호텔', type: '호텔', price: '₩150,000~', rating: '★★★★☆', location: '강릉', description: '해변 바로 앞 호텔' },
        { name: '평창 알펜시아 리조트', type: '리조트', price: '₩200,000~', rating: '★★★★★', location: '평창', description: '스키 리조트' }
    ],
    '충청도': [
        { name: '대전 유성 호텔', type: '호텔', price: '₩100,000~', rating: '★★★☆☆', location: '대전', description: '대전 중심가 호텔' },
        { name: '공주 한옥 게스트하우스', type: '게스트하우스', price: '₩50,000~', rating: '★★★☆☆', location: '공주', description: '전통 한옥 스타일 게스트하우스' },
        { name: '천안 독립기념관 근처 호텔', type: '호텔', price: '₩90,000~', rating: '★★★☆☆', location: '천안', description: '역사 유적지 근처 호텔' }
    ],
    '전라도': [
        { name: '전주 한옥마을 한옥스테이', type: '한옥스테이', price: '₩80,000~', rating: '★★★★☆', location: '전주', description: '전통 한옥에서의 특별한 경험' },
        { name: '여수 오동도 리조트', type: '리조트', price: '₩150,000~', rating: '★★★★☆', location: '여수', description: '바다 전망 리조트' },
        { name: '순천만 펜션', type: '펜션', price: '₩70,000~', rating: '★★★☆☆', location: '순천', description: '갈대밭 근처 조용한 펜션' },
        { name: '목포 해변 호텔', type: '호텔', price: '₩100,000~', rating: '★★★☆☆', location: '목포', description: '해변가 호텔' }
    ],
    '경상도': [
        { name: '부산 해운대 호텔', type: '호텔', price: '₩180,000~', rating: '★★★★★', location: '부산', description: '해운대 해변 바로 앞 호텔' },
        { name: '경주 불국사 근처 리조트', type: '리조트', price: '₩150,000~', rating: '★★★★☆', location: '경주', description: '역사 유적지 근처 리조트' },
        { name: '통영 미륵산 펜션', type: '펜션', price: '₩90,000~', rating: '★★★☆☆', location: '통영', description: '산과 바다가 보이는 펜션' },
        { name: '안동 하회마을 한옥스테이', type: '한옥스테이', price: '₩70,000~', rating: '★★★★☆', location: '안동', description: '전통 마을 한옥 체험' },
        { name: '거제 바다뷰 펜션', type: '펜션', price: '₩100,000~', rating: '★★★★☆', location: '거제', description: '아름다운 바다 전망 펜션' }
    ],
    '제주도': [
        { name: '제주 신라호텔', type: '호텔', price: '₩300,000~', rating: '★★★★★', location: '서귀포', description: '제주 최고급 리조트 호텔' },
        { name: '협재해수욕장 펜션', type: '펜션', price: '₩120,000~', rating: '★★★★☆', location: '제주시', description: '해수욕장 바로 앞 펜션' },
        { name: '성산일출봉 게스트하우스', type: '게스트하우스', price: '₩60,000~', rating: '★★★☆☆', location: '성산', description: '일출봉 전망 게스트하우스' },
        { name: '한라산 근처 리조트', type: '리조트', price: '₩200,000~', rating: '★★★★☆', location: '서귀포', description: '한라산 전망 리조트' },
        { name: '우도 펜션', type: '펜션', price: '₩100,000~', rating: '★★★★☆', location: '우도', description: '우도에서 즐기는 펜션' }
    ]
};

// 지역별 여행지 데이터
const regionData = {
    '서울': {
        places: ['경복궁', '남산타워', '명동', '홍대', '강남', '인사동', '북한산', '한강공원'],
        clothing: ['편안한 운동화', '가벼운 외투', '캐주얼한 옷차림', '모자', '선글라스'],
        items: ['카메라', '지도 앱', '교통카드', '보조배터리', '물통', '간단한 간식']
    },
    '경기도': {
        places: ['에버랜드', '용인 한국민속촌', '수원화성', '가평 쁘띠프랑스', '파주 헤이리', '이천 도예마을'],
        clothing: ['편안한 옷', '운동화', '야외 활동용 옷', '모자', '선크림'],
        items: ['물통', '간식', '카메라', '돗자리', '보조배터리', '휴대용 선풍기']
    },
    '강원도': {
        places: ['설악산', '남이섬', '평창 알펜시아', '정선 아리랑마을', '춘천', '강릉 안목해변'],
        clothing: ['따뜻한 외투', '등산화', '방수 재킷', '모자', '장갑', '목도리'],
        items: ['등산용품', '물통', '간식', '카메라', '보조배터리', '손전등', '응급키트']
    },
    '충청도': {
        places: ['공주 무령왕릉', '부여 정림사지', '천안 독립기념관', '보령 머드축제', '대전 엑스포과학공원'],
        clothing: ['편안한 옷', '운동화', '가벼운 외투', '모자'],
        items: ['카메라', '물통', '간식', '보조배터리', '지도']
    },
    '전라도': {
        places: ['전주 한옥마을', '순천만 갈대밭', '여수 오동도', '담양 죽녹원', '목포 유달산'],
        clothing: ['편안한 옷', '운동화', '가벼운 외투', '모자', '선글라스'],
        items: ['카메라', '물통', '간식', '보조배터리', '돗자리', '선크림']
    },
    '경상도': {
        places: ['부산 해운대', '경주 불국사', '통영 미륵산', '안동 하회마을', '거제 바람의 언덕'],
        clothing: ['수영복', '편안한 옷', '운동화', '모자', '선글라스', '가벼운 외투'],
        items: ['카메라', '물통', '간식', '보조배터리', '선크림', '돗자리']
    },
    '제주도': {
        places: ['한라산', '성산일출봉', '천지연폭포', '협재해수욕장', '우도', '카멜리아힐'],
        clothing: ['수영복', '편안한 옷', '운동화', '모자', '선글라스', '가벼운 외투', '등산화'],
        items: ['카메라', '물통', '간식', '보조배터리', '선크림', '돗자리', '렌터카 예약']
    }
};

// 색깔별 여행지 매핑
const colorToRegions = {
    '빨강': {
        color: '#FF6B6B',
        regions: ['서울', '경기도'],
        reason: '활기찬 도시의 에너지와 빨간색이 잘 어울립니다.'
    },
    '주황': {
        color: '#FFA07A',
        regions: ['제주도', '경상도'],
        reason: '따뜻한 태양과 주황색이 바다 여행에 완벽합니다.'
    },
    '노랑': {
        color: '#FFD93D',
        regions: ['전라도', '충청도'],
        reason: '밝고 따뜻한 노란색이 역사와 문화의 고장에 어울립니다.'
    },
    '초록': {
        color: '#6BCB77',
        regions: ['강원도', '제주도'],
        reason: '자연과 초록색이 산과 바다가 만나는 곳에 완벽합니다.'
    },
    '파랑': {
        color: '#4D96FF',
        regions: ['경상도', '제주도'],
        reason: '파란 하늘과 바다가 있는 해안 지역에 어울립니다.'
    },
    '보라': {
        color: '#9B59B6',
        regions: ['서울', '경기도'],
        reason: '세련된 보라색이 현대적인 도시 여행에 완벽합니다.'
    },
    '분홍': {
        color: '#FF69B4',
        regions: ['제주도', '전라도'],
        reason: '로맨틱한 분홍색이 아름다운 자연 풍경에 어울립니다.'
    },
    '하늘색': {
        color: '#87CEEB',
        regions: ['강원도', '경상도'],
        reason: '맑은 하늘색이 산과 바다가 있는 지역에 완벽합니다.'
    },
    '갈색': {
        color: '#8B4513',
        regions: ['충청도', '전라도'],
        reason: '따뜻한 갈색이 역사적인 유적지와 잘 어울립니다.'
    },
    '검정': {
        color: '#2C3E50',
        regions: ['서울', '강원도'],
        reason: '고급스러운 검정색이 도시와 산악 지역 모두에 어울립니다.'
    },
    '흰색': {
        color: '#FFFFFF',
        regions: ['제주도', '강원도'],
        reason: '순수한 흰색이 깨끗한 자연 환경에 완벽합니다.'
    },
    '회색': {
        color: '#95A5A6',
        regions: ['서울', '경기도'],
        reason: '모던한 회색이 현대적인 도시 여행에 어울립니다.'
    }
};

// 색깔 목록
const colors = Object.keys(colorToRegions);

// DOM 요소
const randomColorBtn = document.getElementById('randomColorBtn');
const selectedColor = document.getElementById('selectedColor');
const colorRecommendation = document.getElementById('colorRecommendation');
const regionCards = document.querySelectorAll('.region-card');
const regionRecommendation = document.getElementById('regionRecommendation');

// 현재 선택된 색깔 정보 저장
let currentColorInfo = null;

// 색깔 랜덤 선택 기능
randomColorBtn.addEventListener('click', () => {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const colorInfo = colorToRegions[randomColor];
    currentColorInfo = { name: randomColor, info: colorInfo };
    
    // 선택된 색깔 표시
    selectedColor.style.backgroundColor = colorInfo.color;
    selectedColor.classList.add('active');
    selectedColor.dataset.colorName = randomColor;
    
    setTimeout(() => {
        selectedColor.classList.remove('active');
    }, 1000);
    
    // 추천 여행지 표시 (클릭 가능하게)
    const regionList = colorInfo.regions.map(region => 
        `<li class="clickable-region" data-region="${region}">${region}</li>`
    ).join('');
    
    colorRecommendation.innerHTML = `
        <h3>${randomColor}색에 어울리는 여행지</h3>
        <p><strong>추천 이유:</strong> ${colorInfo.reason}</p>
        <div class="places-list">
            <h4>추천 지역 (클릭하여 상세 정보 보기):</h4>
            <ul>${regionList}</ul>
        </div>
    `;
    
    colorRecommendation.classList.add('show');
    
    // 색깔 추천에서 나온 지역 목록 클릭 이벤트 추가
    setTimeout(() => {
        const clickableRegions = colorRecommendation.querySelectorAll('.clickable-region');
        clickableRegions.forEach(region => {
            region.addEventListener('click', () => {
                const regionName = region.dataset.region;
                showRegionRecommendation(regionName);
            });
        });
    }, 100);
});

// 색깔 원 클릭 이벤트 (색깔을 다시 클릭하면 추천 지역 목록 표시)
selectedColor.addEventListener('click', () => {
    if (currentColorInfo) {
        const regionList = currentColorInfo.info.regions.map(region => 
            `<li class="clickable-region" data-region="${region}">${region}</li>`
        ).join('');
        
        colorRecommendation.innerHTML = `
            <h3>${currentColorInfo.name}색에 어울리는 여행지</h3>
            <p><strong>추천 이유:</strong> ${currentColorInfo.info.reason}</p>
            <div class="places-list">
                <h4>추천 지역 (클릭하여 상세 정보 보기):</h4>
                <ul>${regionList}</ul>
            </div>
        `;
        
        colorRecommendation.classList.add('show');
        
        // 지역 목록 클릭 이벤트 추가
        setTimeout(() => {
            const clickableRegions = colorRecommendation.querySelectorAll('.clickable-region');
            clickableRegions.forEach(region => {
                region.addEventListener('click', () => {
                    const regionName = region.dataset.region;
                    showRegionRecommendation(regionName);
                });
            });
        }, 100);
    }
});

// 지역 카드 클릭 이벤트
regionCards.forEach(card => {
    card.addEventListener('click', () => {
        const region = card.dataset.region;
        showRegionRecommendation(region);
    });
});

// 지도에서 지역 클릭 이벤트
document.addEventListener('DOMContentLoaded', () => {
    const mapPaths = document.querySelectorAll('.region-path');
    mapPaths.forEach(path => {
        path.addEventListener('click', () => {
            const region = path.dataset.region;
            showRegionRecommendation(region);
        });
    });
    
    // 검색 기능 초기화
    initSearch();
    
    // 예약 기능 초기화
    initBooking();
});

// 검색 기능 초기화
function initSearch() {
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');
    const quickBtns = document.querySelectorAll('.quick-btn');
    const searchResults = document.getElementById('searchResults');
    
    // 검색 버튼 클릭
    searchBtn.addEventListener('click', () => {
        performSearch();
    });
    
    // 엔터키로 검색
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    // 빠른 검색 버튼
    quickBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const region = btn.dataset.region;
            searchInput.value = region;
            performSearch();
        });
    });
    
    // 검색 실행 함수
    function performSearch() {
        const query = searchInput.value.trim();
        if (!query) {
            searchResults.innerHTML = '<p class="no-results">검색어를 입력해주세요.</p>';
            searchResults.classList.add('show');
            return;
        }
        
        const results = searchAccommodations(query);
        displaySearchResults(results, query);
    }
}

// 숙소 검색 함수
function searchAccommodations(query) {
    const results = [];
    const queryLower = query.toLowerCase();
    
    // 지역별로 검색
    Object.keys(accommodationData).forEach(region => {
        if (region.includes(query) || query.includes(region)) {
            accommodationData[region].forEach(accommodation => {
                results.push({ ...accommodation, region: region });
            });
        } else {
            // 숙소명이나 위치로 검색
            accommodationData[region].forEach(accommodation => {
                if (accommodation.name.toLowerCase().includes(queryLower) ||
                    accommodation.location.toLowerCase().includes(queryLower) ||
                    accommodation.type.toLowerCase().includes(queryLower)) {
                    results.push({ ...accommodation, region: region });
                }
            });
        }
    });
    
    return results;
}

// 검색 결과 표시
function displaySearchResults(results, query) {
    const searchResults = document.getElementById('searchResults');
    
    if (results.length === 0) {
        searchResults.innerHTML = `
            <div class="no-results">
                <p>😔 "${query}"에 대한 검색 결과가 없습니다.</p>
                <p>다른 지역명으로 검색해보세요!</p>
            </div>
        `;
    } else {
        const resultsHTML = results.map(accommodation => `
            <div class="accommodation-card">
                <div class="accommodation-header">
                    <h3>${accommodation.name}</h3>
                    <span class="accommodation-type">${accommodation.type}</span>
                </div>
                <div class="accommodation-info">
                    <p class="accommodation-location">📍 ${accommodation.region} - ${accommodation.location}</p>
                    <p class="accommodation-description">${accommodation.description}</p>
                    <div class="accommodation-footer">
                        <span class="accommodation-price">${accommodation.price}</span>
                        <span class="accommodation-rating">${accommodation.rating}</span>
                    </div>
                </div>
            </div>
        `).join('');
        
        searchResults.innerHTML = `
            <div class="results-header">
                <h3>"${query}" 검색 결과 (${results.length}개)</h3>
            </div>
            <div class="accommodation-grid">
                ${resultsHTML}
            </div>
        `;
    }
    
    searchResults.classList.add('show');
    searchResults.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 지역별 추천 표시 함수
function showRegionRecommendation(region) {
    const data = regionData[region];
    
    if (!data) return;
    
    const placesList = data.places.map(place => 
        `<li>${place}</li>`
    ).join('');
    
    const clothingList = data.clothing.map(item => 
        `<li>${item}</li>`
    ).join('');
    
    const itemsList = data.items.map(item => 
        `<li>${item}</li>`
    ).join('');
    
    regionRecommendation.innerHTML = `
        <h3>${region} 여행 추천</h3>
        <div class="recommendation-grid">
            <div class="recommendation-item">
                <h4>📍 주요 여행지</h4>
                <ul>${placesList}</ul>
            </div>
            <div class="recommendation-item">
                <h4>👕 추천 의상</h4>
                <ul>${clothingList}</ul>
            </div>
            <div class="recommendation-item">
                <h4>🎒 추천 용품</h4>
                <ul>${itemsList}</ul>
            </div>
        </div>
    `;
    
    regionRecommendation.classList.add('show');
    
    // 스크롤 이동
    regionRecommendation.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 예약 기능 초기화
function initBooking() {
    const bookingForm = document.getElementById('bookingForm');
    const bookingRegion = document.getElementById('bookingRegion');
    const bookingAccommodation = document.getElementById('bookingAccommodation');
    const bookingDate = document.getElementById('bookingDate');
    const bookingsList = document.getElementById('bookingsList');
    
    // 날짜 입력 필드 최소값을 오늘로 설정
    const today = new Date().toISOString().split('T')[0];
    bookingDate.min = today;
    
    // 지역 선택 시 숙소 목록 업데이트
    bookingRegion.addEventListener('change', () => {
        const selectedRegion = bookingRegion.value;
        updateAccommodationList(selectedRegion);
    });
    
    // 예약 폼 제출
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        handleBookingSubmit();
    });
    
    // 예약 내역 로드 및 표시
    loadBookings();
}

// 숙소 목록 업데이트
function updateAccommodationList(region) {
    const bookingAccommodation = document.getElementById('bookingAccommodation');
    
    if (!region) {
        bookingAccommodation.innerHTML = '<option value="">먼저 지역을 선택하세요</option>';
        bookingAccommodation.disabled = true;
        return;
    }
    
    const accommodations = accommodationData[region] || [];
    bookingAccommodation.innerHTML = '<option value="">숙소를 선택하세요</option>';
    
    accommodations.forEach(accommodation => {
        const option = document.createElement('option');
        option.value = accommodation.name;
        option.textContent = `${accommodation.name} (${accommodation.type}) - ${accommodation.price}`;
        option.dataset.accommodationData = JSON.stringify(accommodation);
        bookingAccommodation.appendChild(option);
    });
    
    bookingAccommodation.disabled = false;
}

// 예약 제출 처리
function handleBookingSubmit() {
    const bookingDate = document.getElementById('bookingDate').value;
    const bookingTime = document.getElementById('bookingTime').value;
    const bookingRegion = document.getElementById('bookingRegion').value;
    const bookingAccommodation = document.getElementById('bookingAccommodation');
    const selectedOption = bookingAccommodation.options[bookingAccommodation.selectedIndex];
    const bookingName = document.getElementById('bookingName').value;
    const bookingPhone = document.getElementById('bookingPhone').value;
    
    if (!bookingDate || !bookingTime || !bookingRegion || !bookingAccommodation.value || !bookingName || !bookingPhone) {
        alert('모든 필드를 입력해주세요.');
        return;
    }
    
    const accommodationData = JSON.parse(selectedOption.dataset.accommodationData);
    
    // 예약 정보 생성
    const booking = {
        id: Date.now(),
        date: bookingDate,
        time: bookingTime,
        region: bookingRegion,
        accommodation: {
            name: accommodationData.name,
            type: accommodationData.type,
            location: accommodationData.location,
            price: accommodationData.price,
            rating: accommodationData.rating
        },
        name: bookingName,
        phone: bookingPhone,
        createdAt: new Date().toISOString()
    };
    
    // 예약 저장
    saveBooking(booking);
    
    // 폼 리셋
    document.getElementById('bookingForm').reset();
    document.getElementById('bookingAccommodation').disabled = true;
    document.getElementById('bookingAccommodation').innerHTML = '<option value="">먼저 지역을 선택하세요</option>';
    
    // 예약 내역 새로고침
    loadBookings();
    
    // 성공 메시지
    alert('예약이 완료되었습니다! ✈️');
}

// 예약 저장 (localStorage)
function saveBooking(booking) {
    let bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    bookings.push(booking);
    localStorage.setItem('bookings', JSON.stringify(bookings));
}

// 예약 내역 로드
function loadBookings() {
    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const bookingsList = document.getElementById('bookingsList');
    
    if (bookings.length === 0) {
        bookingsList.innerHTML = '<p class="no-bookings">예약 내역이 없습니다.</p>';
        return;
    }
    
    // 날짜순으로 정렬 (최신순)
    bookings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const bookingsHTML = bookings.map(booking => {
        const date = new Date(booking.date);
        const formattedDate = `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`;
        const [hours, minutes] = booking.time.split(':');
        const formattedTime = `${hours}시 ${minutes}분`;
        
        return `
            <div class="booking-card">
                <div class="booking-header">
                    <h3>${booking.accommodation.name}</h3>
                    <button class="delete-booking-btn" data-booking-id="${booking.id}">삭제</button>
                </div>
                <div class="booking-info">
                    <div class="booking-detail">
                        <span class="detail-label">✈️ 출발일시:</span>
                        <span class="detail-value">${formattedDate} ${formattedTime}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">📍 지역:</span>
                        <span class="detail-value">${booking.region}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">🏨 숙소:</span>
                        <span class="detail-value">${booking.accommodation.name} (${booking.accommodation.type})</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">📍 위치:</span>
                        <span class="detail-value">${booking.accommodation.location}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">💰 가격:</span>
                        <span class="detail-value">${booking.accommodation.price}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">⭐ 평점:</span>
                        <span class="detail-value">${booking.accommodation.rating}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">👤 예약자:</span>
                        <span class="detail-value">${booking.name}</span>
                    </div>
                    <div class="booking-detail">
                        <span class="detail-label">📞 연락처:</span>
                        <span class="detail-value">${booking.phone}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    bookingsList.innerHTML = bookingsHTML;
    
    // 삭제 버튼 이벤트 추가
    bookingsList.querySelectorAll('.delete-booking-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const bookingId = parseInt(btn.dataset.bookingId);
            if (confirm('정말 이 예약을 취소하시겠습니까?')) {
                deleteBooking(bookingId);
            }
        });
    });
}

// 예약 삭제
function deleteBooking(bookingId) {
    let bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    bookings = bookings.filter(booking => booking.id !== bookingId);
    localStorage.setItem('bookings', JSON.stringify(bookings));
    loadBookings();
}
