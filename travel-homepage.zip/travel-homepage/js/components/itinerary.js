// Itinerary Component - 여행 일정표 관리

/**
 * 일정표 생성 및 관리 컴포넌트
 */

// 일정표 HTML 생성
function createItineraryView(plan) {
    if (!plan || !plan.itinerary || plan.itinerary.length === 0) {
        return `
            <div class="itinerary-empty">
                <p>아직 일정이 없습니다.</p>
                <button class="btn btn-primary" onclick="addItineraryDay('${plan.id}')">
                    첫 일정 추가하기
                </button>
            </div>
        `;
    }

    return `
        <div class="itinerary-container">
            <div class="itinerary-header">
                <h3>여행 일정표</h3>
                <button class="btn btn-sm btn-primary" onclick="addItineraryDay('${plan.id}')">
                    + 일정 추가
                </button>
            </div>
            <div class="itinerary-timeline">
                ${plan.itinerary.map((day, index) => createDayCard(plan.id, day, index)).join('')}
            </div>
        </div>
    `;
}

// 일별 카드 생성
function createDayCard(planId, day, dayIndex) {
    const totalCost = day.activities.reduce((sum, activity) => sum + (activity.cost || 0), 0);

    return `
        <div class="day-card" data-day="${dayIndex}">
            <div class="day-header">
                <div class="day-info">
                    <h4>Day ${day.day}</h4>
                    <span class="day-date">${formatDate(day.date, 'YYYY년 MM월 DD일 (ddd)')}</span>
                </div>
                <div class="day-actions">
                    <span class="day-cost">${formatCurrency(totalCost)}</span>
                    <button class="btn-icon" onclick="addActivity('${planId}', ${dayIndex})" title="활동 추가">
                        <span>+</span>
                    </button>
                    <button class="btn-icon" onclick="removeDayFromItinerary('${planId}', ${dayIndex})" title="일정 삭제">
                        <span>×</span>
                    </button>
                </div>
            </div>
            <div class="activities-list">
                ${day.activities && day.activities.length > 0
            ? day.activities.map((activity, actIndex) =>
                createActivityItem(planId, dayIndex, activity, actIndex)
            ).join('')
            : '<p class="no-activities">활동이 없습니다. 활동을 추가해보세요!</p>'
        }
            </div>
        </div>
    `;
}

// 활동 아이템 생성
function createActivityItem(planId, dayIndex, activity, actIndex) {
    return `
        <div class="activity-item" data-activity="${actIndex}">
            <div class="activity-time">${activity.time || '시간 미정'}</div>
            <div class="activity-content">
                <div class="activity-title">${escapeHtml(activity.title)}</div>
                ${activity.description ? `<div class="activity-description">${escapeHtml(activity.description)}</div>` : ''}
                ${activity.location ? `<div class="activity-location">📍 ${escapeHtml(activity.location)}</div>` : ''}
            </div>
            <div class="activity-cost">${activity.cost > 0 ? formatCurrency(activity.cost) : '-'}</div>
            <div class="activity-actions">
                <button class="btn-icon-sm" onclick="editActivity('${planId}', ${dayIndex}, ${actIndex})" title="수정">
                    ✏️
                </button>
                <button class="btn-icon-sm" onclick="removeActivity('${planId}', ${dayIndex}, ${actIndex})" title="삭제">
                    🗑️
                </button>
            </div>
        </div>
    `;
}

// 일정 추가
function addItineraryDay(planId) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan) return;

    const dayNumber = (plan.itinerary?.length || 0) + 1;
    const startDate = new Date(plan.startDate);
    const newDate = new Date(startDate);
    newDate.setDate(startDate.getDate() + dayNumber - 1);

    const content = `
        <form id="add-day-form" onsubmit="event.preventDefault(); saveNewDay('${planId}');">
            <div class="form-group">
                <label class="form-label">날짜</label>
                <input type="date" id="day-date" class="form-input" 
                       value="${newDate.toISOString().split('T')[0]}" required>
            </div>
            <div class="form-group">
                <label class="form-label">Day 번호</label>
                <input type="number" id="day-number" class="form-input" 
                       value="${dayNumber}" min="1" required>
            </div>
        </form>
    `;

    modal.show('새 일정 추가', content, [
        { label: '취소', className: 'btn-secondary', onClick: 'modal.close()' },
        { label: '추가', className: 'btn-primary', onClick: 'document.getElementById("add-day-form").requestSubmit()' }
    ], 'small');
}

// 새 일정 저장
function saveNewDay(planId) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan) return;

    const date = document.getElementById('day-date').value;
    const dayNumber = parseInt(document.getElementById('day-number').value);

    if (!plan.itinerary) plan.itinerary = [];

    plan.itinerary.push({
        day: dayNumber,
        date: date,
        activities: []
    });

    // day 번호로 정렬
    plan.itinerary.sort((a, b) => a.day - b.day);

    storage.update('travelPlans', planId, plan);
    modal.close();
    toast.success('일정이 추가되었습니다');

    // 페이지 새로고침
    if (typeof renderPlannerPage === 'function') {
        renderPlannerPage();
    }
}

// 일정 삭제
function removeDayFromItinerary(planId, dayIndex) {
    if (!confirm('이 날의 일정을 삭제하시겠습니까?')) return;

    const plan = storage.findById('travelPlans', planId);
    if (!plan || !plan.itinerary) return;

    plan.itinerary.splice(dayIndex, 1);
    storage.update('travelPlans', planId, plan);
    toast.success('일정이 삭제되었습니다');

    if (typeof renderPlannerPage === 'function') {
        renderPlannerPage();
    }
}

// 활동 추가
function addActivity(planId, dayIndex) {
    const content = `
        <form id="add-activity-form" onsubmit="event.preventDefault(); saveNewActivity('${planId}', ${dayIndex});">
            <div class="form-group">
                <label class="form-label">시간</label>
                <input type="time" id="activity-time" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">활동 제목</label>
                <input type="text" id="activity-title" class="form-input" 
                       placeholder="예: 한라산 등반" required>
            </div>
            <div class="form-group">
                <label class="form-label">설명 (선택)</label>
                <textarea id="activity-description" class="form-textarea" 
                          placeholder="활동에 대한 설명을 입력하세요"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">장소 (선택)</label>
                <input type="text" id="activity-location" class="form-input" 
                       placeholder="예: 제주시 한라산국립공원">
            </div>
            <div class="form-group">
                <label class="form-label">비용 (원)</label>
                <input type="number" id="activity-cost" class="form-input" 
                       min="0" step="1000" value="0">
            </div>
        </form>
    `;

    modal.show('활동 추가', content, [
        { label: '취소', className: 'btn-secondary', onClick: 'modal.close()' },
        { label: '추가', className: 'btn-primary', onClick: 'document.getElementById("add-activity-form").requestSubmit()' }
    ]);
}

// 새 활동 저장
function saveNewActivity(planId, dayIndex) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan || !plan.itinerary || !plan.itinerary[dayIndex]) return;

    const activity = {
        time: document.getElementById('activity-time').value,
        title: document.getElementById('activity-title').value,
        description: document.getElementById('activity-description').value,
        location: document.getElementById('activity-location').value,
        cost: parseInt(document.getElementById('activity-cost').value) || 0
    };

    plan.itinerary[dayIndex].activities.push(activity);

    // 시간순으로 정렬
    plan.itinerary[dayIndex].activities.sort((a, b) => a.time.localeCompare(b.time));

    storage.update('travelPlans', planId, plan);
    modal.close();
    toast.success('활동이 추가되었습니다');

    if (typeof renderPlannerPage === 'function') {
        renderPlannerPage();
    }
}

// 활동 수정
function editActivity(planId, dayIndex, actIndex) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan || !plan.itinerary || !plan.itinerary[dayIndex]) return;

    const activity = plan.itinerary[dayIndex].activities[actIndex];
    if (!activity) return;

    const content = `
        <form id="edit-activity-form" onsubmit="event.preventDefault(); updateActivity('${planId}', ${dayIndex}, ${actIndex});">
            <div class="form-group">
                <label class="form-label">시간</label>
                <input type="time" id="activity-time" class="form-input" 
                       value="${activity.time}" required>
            </div>
            <div class="form-group">
                <label class="form-label">활동 제목</label>
                <input type="text" id="activity-title" class="form-input" 
                       value="${escapeHtml(activity.title)}" required>
            </div>
            <div class="form-group">
                <label class="form-label">설명 (선택)</label>
                <textarea id="activity-description" class="form-textarea">${escapeHtml(activity.description || '')}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">장소 (선택)</label>
                <input type="text" id="activity-location" class="form-input" 
                       value="${escapeHtml(activity.location || '')}">
            </div>
            <div class="form-group">
                <label class="form-label">비용 (원)</label>
                <input type="number" id="activity-cost" class="form-input" 
                       min="0" step="1000" value="${activity.cost || 0}">
            </div>
        </form>
    `;

    modal.show('활동 수정', content, [
        { label: '취소', className: 'btn-secondary', onClick: 'modal.close()' },
        { label: '저장', className: 'btn-primary', onClick: 'document.getElementById("edit-activity-form").requestSubmit()' }
    ]);
}

// 활동 업데이트
function updateActivity(planId, dayIndex, actIndex) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan || !plan.itinerary || !plan.itinerary[dayIndex]) return;

    plan.itinerary[dayIndex].activities[actIndex] = {
        time: document.getElementById('activity-time').value,
        title: document.getElementById('activity-title').value,
        description: document.getElementById('activity-description').value,
        location: document.getElementById('activity-location').value,
        cost: parseInt(document.getElementById('activity-cost').value) || 0
    };

    // 시간순으로 정렬
    plan.itinerary[dayIndex].activities.sort((a, b) => a.time.localeCompare(b.time));

    storage.update('travelPlans', planId, plan);
    modal.close();
    toast.success('활동이 수정되었습니다');

    if (typeof renderPlannerPage === 'function') {
        renderPlannerPage();
    }
}

// 활동 삭제
function removeActivity(planId, dayIndex, actIndex) {
    if (!confirm('이 활동을 삭제하시겠습니까?')) return;

    const plan = storage.findById('travelPlans', planId);
    if (!plan || !plan.itinerary || !plan.itinerary[dayIndex]) return;

    plan.itinerary[dayIndex].activities.splice(actIndex, 1);
    storage.update('travelPlans', planId, plan);
    toast.success('활동이 삭제되었습니다');

    if (typeof renderPlannerPage === 'function') {
        renderPlannerPage();
    }
}
