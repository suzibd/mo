// Toast Component

class Toast {
    constructor() {
        this.container = document.getElementById('toast-container');
    }

    show(message, type = 'info', duration = 3000) {
        const id = `toast-${Date.now()}`;
        const icons = {
            info: 'ℹ️',
            success: '✅',
            warning: '⚠️',
            error: '❌'
        };

        const toastHTML = `
            <div class="toast toast-${type}" id="${id}">
                <span class="toast-icon">${icons[type]}</span>
                <span class="toast-message">${escapeHtml(message)}</span>
                <button class="toast-close" onclick="toast.remove('${id}')" aria-label="닫기">×</button>
            </div>
        `;

        this.container.insertAdjacentHTML('beforeend', toastHTML);

        const toastElement = document.getElementById(id);

        // 애니메이션
        setTimeout(() => {
            toastElement.classList.add('show');
        }, 10);

        // 자동 제거
        setTimeout(() => {
            this.remove(id);
        }, duration);
    }

    remove(id) {
        const toastElement = document.getElementById(id);
        if (toastElement) {
            toastElement.classList.remove('show');
            setTimeout(() => {
                toastElement.remove();
            }, 300);
        }
    }

    success(message, duration) {
        this.show(message, 'success', duration);
    }

    error(message, duration) {
        this.show(message, 'error', duration);
    }

    warning(message, duration) {
        this.show(message, 'warning', duration);
    }

    info(message, duration) {
        this.show(message, 'info', duration);
    }
}

// 전역 토스트 인스턴스
const toast = new Toast();

// 토스트 스타일 추가
const toastStyles = `
<style>
#toast-container {
    position: fixed;
    top: 80px;
    right: var(--spacing-md);
    z-index: var(--z-toast);
    display: flex;
    flex-direction: column;
    gap: var(--spacing-sm);
    max-width: 400px;
}

.toast {
    background-color: var(--color-background);
    border-radius: var(--radius-md);
    padding: var(--spacing-md);
    box-shadow: var(--shadow-lg);
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    opacity: 0;
    transform: translateX(100%);
    transition: all var(--transition-base);
    border-left: 4px solid;
}

.toast.show {
    opacity: 1;
    transform: translateX(0);
}

.toast-info {
    border-left-color: var(--color-info);
}

.toast-success {
    border-left-color: var(--color-success);
}

.toast-warning {
    border-left-color: var(--color-warning);
}

.toast-error {
    border-left-color: var(--color-error);
}

.toast-icon {
    font-size: var(--font-size-xl);
    flex-shrink: 0;
}

.toast-message {
    flex: 1;
    color: var(--color-text-primary);
}

.toast-close {
    font-size: var(--font-size-xl);
    line-height: 1;
    color: var(--color-text-secondary);
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-sm);
    transition: all var(--transition-fast);
    flex-shrink: 0;
}

.toast-close:hover {
    background-color: var(--color-surface);
    color: var(--color-text-primary);
}

@media (max-width: 768px) {
    #toast-container {
        right: var(--spacing-sm);
        left: var(--spacing-sm);
        max-width: none;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', toastStyles);
