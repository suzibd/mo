// Gallery Component

/**
 * 사진 갤러리 컴포넌트
 */

function createGallery(mediaList, options = {}) {
    const { columns = 3, showLightbox = true } = options;

    if (!mediaList || mediaList.length === 0) {
        return '<div class="gallery-empty"><p>사진이 없습니다</p></div>';
    }

    return `
        <div class="gallery-container" data-columns="${columns}">
            <div class="gallery-grid">
                ${mediaList.map((media, index) => createGalleryItem(media, index, showLightbox)).join('')}
            </div>
        </div>
    `;
}

function createGalleryItem(media, index, showLightbox) {
    const isImage = media.fileType.startsWith('image/');
    const isVideo = media.fileType.startsWith('video/');

    return `
        <div class="gallery-item" data-index="${index}" data-media-id="${media.id}">
            <div class="gallery-item-inner" ${showLightbox ? `onclick="openLightbox(${index})"` : ''}>
                ${isImage ? `
                    <img src="${media.data}" alt="${media.fileName}" class="gallery-image">
                ` : ''}
                ${isVideo ? `
                    <video class="gallery-video" ${!showLightbox ? 'controls' : ''}>
                        <source src="${media.data}" type="${media.fileType}">
                    </video>
                    <div class="video-overlay">▶</div>
                ` : ''}
            </div>
            ${media.description ? `<p class="gallery-caption">${escapeHtml(media.description)}</p>` : ''}
        </div>
    `;
}

// 라이트박스 열기
let currentLightboxIndex = 0;
let lightboxMedia = [];

function openLightbox(index) {
    currentLightboxIndex = index;

    // 현재 갤러리의 모든 미디어 가져오기
    const galleryItems = document.querySelectorAll('.gallery-item');
    lightboxMedia = Array.from(galleryItems).map(item => {
        const mediaId = item.dataset.mediaId;
        const img = item.querySelector('img');
        const video = item.querySelector('video');

        return {
            id: mediaId,
            src: img ? img.src : (video ? video.querySelector('source').src : ''),
            type: img ? 'image' : 'video',
            caption: item.querySelector('.gallery-caption')?.textContent || ''
        };
    });

    showLightbox();
}

function showLightbox() {
    const media = lightboxMedia[currentLightboxIndex];
    if (!media) return;

    const lightboxHTML = `
        <div class="lightbox-overlay" id="lightbox" onclick="closeLightboxOnOverlay(event)">
            <div class="lightbox-content">
                <button class="lightbox-close" onclick="closeLightbox()">×</button>
                
                ${currentLightboxIndex > 0 ? `
                    <button class="lightbox-nav lightbox-prev" onclick="navigateLightbox(-1)">‹</button>
                ` : ''}
                
                ${currentLightboxIndex < lightboxMedia.length - 1 ? `
                    <button class="lightbox-nav lightbox-next" onclick="navigateLightbox(1)">›</button>
                ` : ''}
                
                <div class="lightbox-media">
                    ${media.type === 'image' ? `
                        <img src="${media.src}" alt="Image">
                    ` : `
                        <video controls autoplay>
                            <source src="${media.src}">
                        </video>
                    `}
                </div>
                
                ${media.caption ? `
                    <div class="lightbox-caption">${escapeHtml(media.caption)}</div>
                ` : ''}
                
                <div class="lightbox-counter">
                    ${currentLightboxIndex + 1} / ${lightboxMedia.length}
                </div>
            </div>
        </div>
    `;

    // 기존 라이트박스 제거
    const existingLightbox = document.getElementById('lightbox');
    if (existingLightbox) {
        existingLightbox.remove();
    }

    // 새 라이트박스 추가
    document.body.insertAdjacentHTML('beforeend', lightboxHTML);
    document.body.style.overflow = 'hidden';

    // ESC 키로 닫기
    document.addEventListener('keydown', handleLightboxKeydown);
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.remove();
    }
    document.body.style.overflow = '';
    document.removeEventListener('keydown', handleLightboxKeydown);
}

function closeLightboxOnOverlay(event) {
    if (event.target.id === 'lightbox') {
        closeLightbox();
    }
}

function navigateLightbox(direction) {
    currentLightboxIndex += direction;
    if (currentLightboxIndex < 0) currentLightboxIndex = 0;
    if (currentLightboxIndex >= lightboxMedia.length) currentLightboxIndex = lightboxMedia.length - 1;
    showLightbox();
}

function handleLightboxKeydown(e) {
    if (e.key === 'Escape') {
        closeLightbox();
    } else if (e.key === 'ArrowLeft') {
        navigateLightbox(-1);
    } else if (e.key === 'ArrowRight') {
        navigateLightbox(1);
    }
}

// 미디어 갤러리 로드
async function loadMediaGallery(relatedId, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    try {
        const mediaList = await mediaStorage.getMediaByRelatedId(relatedId);
        container.innerHTML = createGallery(mediaList);
    } catch (error) {
        console.error('갤러리 로드 실패:', error);
        container.innerHTML = '<p>갤러리를 불러올 수 없습니다.</p>';
    }
}
