// Modal Component

class Modal {
    constructor() {
        this.container = document.getElementById('modal-container');
    }

    show(title, content, actions = [], size = 'normal') {
        const sizeClass = size === 'small' ? 'small' : size === 'large' ? 'large' : '';
        const modalHTML = `
            <div class="modal-overlay" id="modal-overlay">
                <div class="modal-content ${sizeClass}">
                    <div class="modal-header">
                        <h2>${title}</h2>
                        <button class="modal-close" onclick="modal.close()" aria-label="닫기">×</button>
                    </div>
                    <div class="modal-body">
                        ${content}
                    </div>
                    ${actions.length > 0 ? `
                        <div class="modal-footer">
                            ${actions.map(action => `
                                <button class="btn ${action.className || 'btn-secondary'}"
                                        onclick="${action.onClick}">
                                    ${action.label}
                                </button>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        this.container.innerHTML = modalHTML;
        document.body.style.overflow = 'hidden';

        // 오버레이 클릭 시 닫기
        const overlay = document.getElementById('modal-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                this.close();
            }
        });

        // ESC 키로 닫기
        this.escapeHandler = (e) => {
            if (e.key === 'Escape') {
                this.close();
            }
        };
        document.addEventListener('keydown', this.escapeHandler);
    }

    close() {
        this.container.innerHTML = '';
        document.body.style.overflow = '';
        if (this.escapeHandler) {
            document.removeEventListener('keydown', this.escapeHandler);
        }
    }

    confirm(title, message, onConfirm, onCancel = null) {
        this.show(title, `<p>${message}</p>`, [
            {
                label: '취소',
                className: 'btn-secondary',
                onClick: onCancel ? `modal.close(); (${onCancel})()` : 'modal.close()'
            },
            {
                label: '확인',
                className: 'btn-primary',
                onClick: `modal.close(); (${onConfirm})()`
            }
        ]);
    }

    showColorPicker(regionName, onColorSelect) {
        const colors = typeof AVAILABLE_COLORS !== 'undefined' ? AVAILABLE_COLORS : [];
        const colorNames = typeof COLOR_NAMES !== 'undefined' ? COLOR_NAMES : {};

        // 랜덤 색상 선택
        const randomColor = colors[Math.floor(Math.random() * colors.length)];

        const colorOptions = colors.map(color => {
            const colorName = colorNames[color] || '색상';
            const isRandom = color === randomColor;
            return `
                <div class="color-option ${isRandom ? 'random-color' : ''}" 
                     data-color="${color}"
                     onclick="window.selectColorFromModal('${color}', '${regionName}')">
                    <div class="color-preview" style="background-color: ${color};"></div>
                    <div class="color-info">
                        <span class="color-name">${colorName}</span>
                        ${isRandom ? '<span class="random-badge">랜덤 선택!</span>' : ''}
                    </div>
                </div>
            `;
        }).join('');

        const content = `
            <div class="color-picker-modal">
                <p class="color-picker-description">
                    <strong>${regionName}</strong> 지역의 색상을 선택하세요
                </p>
                <div class="color-options-grid">
                    ${colorOptions}
                </div>
            </div>
        `;

        // 전역 함수로 색상 선택 핸들러 등록
        window.selectColorFromModal = (color, region) => {
            modal.close();
            if (onColorSelect) {
                onColorSelect(color, region);
            }
        };

        this.show('색상 선택', content, [], 'normal');
    }
}

// 전역 모달 인스턴스
const modal = new Modal();

// 모달 스타일 추가
const modalStyles = `
<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: var(--z-modal);
    padding: var(--spacing-md);
}

.modal-content {
    background-color: var(--color-background);
    border-radius: var(--radius-lg);
    max-width: 600px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: var(--shadow-xl);
    animation: modalSlideIn 0.3s ease-out;
}

.modal-content.small {
    max-width: 400px;
}

.modal-content.large {
    max-width: 800px;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-header {
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--color-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    font-size: var(--font-size-xl);
}

.modal-close {
    font-size: 2rem;
    line-height: 1;
    color: var(--color-text-secondary);
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-sm);
    transition: all var(--transition-fast);
}

.modal-close:hover {
    background-color: var(--color-surface);
    color: var(--color-text-primary);
}

.modal-body {
    padding: var(--spacing-lg);
}

.modal-footer {
    padding: var(--spacing-lg);
    border-top: 1px solid var(--color-border);
    display: flex;
    justify-content: flex-end;
    gap: var(--spacing-sm);
}

/* 색상 선택 모달 스타일 */
.color-picker-modal {
    width: 100%;
}

.color-picker-description {
    margin-bottom: var(--spacing-lg);
    font-size: var(--font-size-base);
    color: var(--color-text-secondary);
    text-align: center;
}

.color-picker-description strong {
    color: var(--color-text-primary);
    font-weight: var(--font-weight-bold);
}

.color-options-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--spacing-md);
}

.color-option {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    padding: var(--spacing-md);
    border: 2px solid var(--color-border);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: all 0.3s ease;
    background-color: var(--color-surface);
}

.color-option:hover {
    border-color: var(--color-primary);
    background-color: var(--color-background);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.color-option.random-color {
    border-color: #FFD700;
    background: linear-gradient(135deg, #fff9e6 0%, #fffef0 100%);
    position: relative;
    animation: randomPulse 2s ease-in-out infinite;
}

@keyframes randomPulse {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.4);
    }
    50% {
        box-shadow: 0 0 0 8px rgba(255, 215, 0, 0);
    }
}

.color-option.random-color:hover {
    border-color: #FFA500;
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 6px 16px rgba(255, 215, 0, 0.3);
}

.color-preview {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    border: 3px solid white;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    flex-shrink: 0;
}

.color-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: var(--spacing-xs);
}

.color-name {
    font-size: var(--font-size-base);
    font-weight: var(--font-weight-medium);
    color: var(--color-text-primary);
}

.random-badge {
    display: inline-block;
    font-size: var(--font-size-xs);
    color: #FF6B00;
    font-weight: var(--font-weight-bold);
    padding: 2px 8px;
    background-color: rgba(255, 215, 0, 0.2);
    border-radius: var(--radius-sm);
    animation: badgeBounce 1s ease-in-out infinite;
}

@keyframes badgeBounce {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-2px);
    }
}

@media (max-width: 480px) {
    .color-options-grid {
        grid-template-columns: 1fr;
    }
    
    .color-preview {
        width: 40px;
        height: 40px;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', modalStyles);
