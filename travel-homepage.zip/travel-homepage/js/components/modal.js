// Modal Component

class Modal {
    constructor() {
        this.container = document.getElementById('modal-container');
    }

    show(title, content, actions = []) {
        const modalHTML = `
            <div class="modal-overlay" id="modal-overlay">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>${title}</h2>
                        <button class="modal-close" onclick="modal.close()" aria-label="닫기">×</button>
                    </div>
                    <div class="modal-body">
                        ${content}
                    </div>
                    ${actions.length > 0 ? `
                        <div class="modal-footer">
                            ${actions.map(action => `
                                <button class="btn ${action.className || 'btn-secondary'}"
                                        onclick="${action.onClick}">
                                    ${action.label}
                                </button>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        this.container.innerHTML = modalHTML;
        document.body.style.overflow = 'hidden';

        // 오버레이 클릭 시 닫기
        const overlay = document.getElementById('modal-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                this.close();
            }
        });

        // ESC 키로 닫기
        this.escapeHandler = (e) => {
            if (e.key === 'Escape') {
                this.close();
            }
        };
        document.addEventListener('keydown', this.escapeHandler);
    }

    close() {
        this.container.innerHTML = '';
        document.body.style.overflow = '';
        if (this.escapeHandler) {
            document.removeEventListener('keydown', this.escapeHandler);
        }
    }

    confirm(title, message, onConfirm, onCancel = null) {
        this.show(title, `<p>${message}</p>`, [
            {
                label: '취소',
                className: 'btn-secondary',
                onClick: onCancel ? `modal.close(); (${onCancel})()` : 'modal.close()'
            },
            {
                label: '확인',
                className: 'btn-primary',
                onClick: `modal.close(); (${onConfirm})()`
            }
        ]);
    }
}

// 전역 모달 인스턴스
const modal = new Modal();

// 모달 스타일 추가
const modalStyles = `
<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: var(--z-modal);
    padding: var(--spacing-md);
}

.modal-content {
    background-color: var(--color-background);
    border-radius: var(--radius-lg);
    max-width: 600px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: var(--shadow-xl);
    animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-header {
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--color-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    font-size: var(--font-size-xl);
}

.modal-close {
    font-size: 2rem;
    line-height: 1;
    color: var(--color-text-secondary);
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-sm);
    transition: all var(--transition-fast);
}

.modal-close:hover {
    background-color: var(--color-surface);
    color: var(--color-text-primary);
}

.modal-body {
    padding: var(--spacing-lg);
}

.modal-footer {
    padding: var(--spacing-lg);
    border-top: 1px solid var(--color-border);
    display: flex;
    justify-content: flex-end;
    gap: var(--spacing-sm);
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', modalStyles);
