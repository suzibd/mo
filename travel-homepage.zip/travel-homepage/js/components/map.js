// 한국 지도 컴포넌트

// 지역별 좌표 (이미지 위 위치: 0-100%)
const REGION_COORDINATES = {
    '서울': { x: 48, y: 32, labelX: 48, labelY: 27 },
    '인천': { x: 38, y: 32, labelX: 38, labelY: 27 },
    '부산': { x: 72, y: 72, labelX: 72, labelY: 67 },
    '제주': { x: 32, y: 88, labelX: 32, labelY: 83 },
    '강릉': { x: 70, y: 35, labelX: 70, labelY: 30 },
    '전주': { x: 42, y: 56, labelX: 42, labelY: 51 },
    '경주': { x: 68, y: 58, labelX: 68, labelY: 53 },
    '여수': { x: 52, y: 72, labelX: 52, labelY: 67 }
};

function createKoreaMap(onRegionClick) {
    if (!onRegionClick) {
        onRegionClick = (regionName) => {
            console.log('지역 클릭:', regionName);
        };
    }

    let mapHTML = `
        <div class="korea-map-container">
            <div class="map-header">
                <h3 class="map-title">지도에서 지역을 선택하세요</h3>
                <p class="map-subtitle">원하는 지역을 클릭하면 해당 지역의 여행지를 추천해드립니다</p>
            </div>
            <div class="map-wrapper">
                <div class="map-image-container">
                    <img src="assets/images/korea-map.png" alt="한국 지도" class="korea-map-image">
                    <div class="map-markers-overlay">
    `;


    // 각 지역 마커 추가
    Object.keys(REGION_COORDINATES).forEach(region => {
        const coords = REGION_COORDINATES[region];
        const color = typeof REGION_COLOR_MAP !== 'undefined' && REGION_COLOR_MAP[region]
            ? REGION_COLOR_MAP[region]
            : '#757575';

        mapHTML += `
            <div class="region-marker-wrapper" 
                 style="left: ${coords.x}%; top: ${coords.y}%;"
                 data-region="${region}">
                <div class="region-marker" 
                     style="background-color: ${color};">
                </div>
                <div class="region-label">${region}</div>
            </div>
        `;
    });

    mapHTML += `
                    </div>
                </div>
            </div>
            <div class="map-legend">
                <h4 class="legend-title">지역별 색상</h4>
                <div class="legend-items">
    `;

    // 범례 추가
    Object.keys(REGION_COLOR_MAP).forEach(region => {
        const color = REGION_COLOR_MAP[region];
        const colorName = typeof COLOR_NAMES !== 'undefined' && COLOR_NAMES[color]
            ? COLOR_NAMES[color]
            : '색상';
        mapHTML += `
            <div class="legend-item" data-region="${region}" style="cursor: pointer;">
                <span class="legend-color" style="background-color: ${color};"></span>
                <span class="legend-label">${region}</span>
                <span class="legend-color-name">${colorName}</span>
            </div>
        `;
    });

    mapHTML += `
                </div>
            </div>
        </div>
    `;

    return mapHTML;
}

function attachMapEventListeners(onRegionClick) {
    // 지역 마커 클릭 이벤트
    document.querySelectorAll('.region-marker-wrapper').forEach(wrapper => {
        wrapper.addEventListener('click', function (e) {
            const region = this.getAttribute('data-region');
            if (region && onRegionClick) {
                onRegionClick(region);
            }
        });

        wrapper.addEventListener('mouseenter', function () {
            const marker = this.querySelector('.region-marker');
            if (marker) {
                marker.style.transform = 'scale(1.3)';
                marker.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.4)';
            }
        });

        wrapper.addEventListener('mouseleave', function () {
            const marker = this.querySelector('.region-marker');
            if (marker) {
                marker.style.transform = 'scale(1)';
                marker.style.boxShadow = '0 2px 6px rgba(0, 0, 0, 0.3)';
            }
        });
    });

    // 범례 클릭 이벤트
    document.querySelectorAll('.legend-item').forEach(item => {
        item.addEventListener('click', function () {
            const region = this.getAttribute('data-region');
            if (region && onRegionClick) {
                onRegionClick(region);
            }
        });
    });
}

