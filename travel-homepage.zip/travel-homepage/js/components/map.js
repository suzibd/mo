// 한국 지도 컴포넌트

// 지역별 좌표 (SVG 뷰포트 내 위치: 0-100%)
const REGION_COORDINATES = {
    '서울': { x: 45, y: 30, labelX: 45, labelY: 25 },
    '부산': { x: 75, y: 80, labelX: 75, labelY: 75 },
    '제주도': { x: 50, y: 95, labelX: 50, labelY: 90 },
    '강릉': { x: 80, y: 35, labelX: 80, labelY: 30 },
    '전주': { x: 35, y: 50, labelX: 35, labelY: 45 },
    '경주': { x: 75, y: 60, labelX: 75, labelY: 55 },
    '속초': { x: 85, y: 15, labelX: 85, labelY: 10 },
    '여수': { x: 65, y: 75, labelX: 65, labelY: 70 }
};

// 한국 지도 SVG 경로 (간단한 형태)
// 본토
const KOREA_MAINLAND_PATH = "M 30 8 L 35 10 L 42 12 L 48 16 L 55 22 L 60 28 L 63 35 L 65 42 L 67 50 L 70 58 L 72 65 L 73 72 L 72 78 L 70 83 L 67 87 L 63 90 L 58 92 L 52 93 L 45 92 L 38 90 L 32 86 L 28 81 L 26 75 L 25 68 L 26 60 L 28 52 L 30 45 L 32 38 L 33 30 L 32 22 L 30 15 Z";
// 제주도
const JEJU_PATH = "M 47 94 L 50 96 L 53 94 L 52 97 L 50 98 L 48 97 Z";

function createKoreaMap(onRegionClick) {
    if (!onRegionClick) {
        onRegionClick = (regionName) => {
            console.log('지역 클릭:', regionName);
        };
    }

    let mapHTML = `
        <div class="korea-map-container">
            <div class="map-header">
                <h3 class="map-title">지도에서 지역을 선택하세요</h3>
                <p class="map-subtitle">원하는 지역을 클릭하면 해당 지역의 여행지를 추천해드립니다</p>
            </div>
            <div class="map-wrapper">
                <svg class="korea-map-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
                    <!-- 한국 지도 본토 -->
                    <path class="korea-mainland" d="${KOREA_MAINLAND_PATH}" fill="#f8f8f8" stroke="#d0d0d0" stroke-width="0.4"/>
                    
                    <!-- 제주도 -->
                    <path class="korea-jeju" d="${JEJU_PATH}" fill="#f8f8f8" stroke="#d0d0d0" stroke-width="0.3"/>
                    
                    <!-- 제주도 마커 -->
                    <circle class="region-marker jeju" cx="50" cy="95.5" r="2.5" fill="${typeof REGION_COLOR_MAP !== 'undefined' && REGION_COLOR_MAP['제주도'] ? REGION_COLOR_MAP['제주도'] : '#4CAF50'}" stroke="white" stroke-width="0.3" data-region="제주도" style="cursor: pointer; transition: all 0.3s ease;"/>
                    <text class="region-label jeju-label" x="50" y="91" text-anchor="middle" font-size="2.2" fill="#333" font-weight="bold" pointer-events="none">제주</text>
    `;

    // 각 지역 마커 추가
    Object.keys(REGION_COORDINATES).forEach(region => {
        if (region === '제주도') return; // 제주도는 이미 추가됨
        
        const coords = REGION_COORDINATES[region];
        const color = typeof REGION_COLOR_MAP !== 'undefined' && REGION_COLOR_MAP[region] 
            ? REGION_COLOR_MAP[region] 
            : '#757575';
        
        mapHTML += `
            <circle class="region-marker ${region.toLowerCase().replace(' ', '-')}" 
                    cx="${coords.x}" 
                    cy="${coords.y}" 
                    r="2.5" 
                    fill="${color}" 
                    stroke="white" 
                    stroke-width="0.4"
                    data-region="${region}"
                    style="cursor: pointer; transition: all 0.3s ease;"/>
            <text class="region-label ${region.toLowerCase().replace(' ', '-')}-label" 
                  x="${coords.labelX}" 
                  y="${coords.labelY}" 
                  text-anchor="middle" 
                  font-size="2.2" 
                  fill="#333"
                  font-weight="bold"
                  pointer-events="none">${region}</text>
        `;
    });

    mapHTML += `
                </svg>
            </div>
            <div class="map-legend">
                <h4 class="legend-title">지역별 색상</h4>
                <div class="legend-items">
    `;

    // 범례 추가
    Object.keys(REGION_COLOR_MAP).forEach(region => {
        const color = REGION_COLOR_MAP[region];
        const colorName = typeof COLOR_NAMES !== 'undefined' && COLOR_NAMES[color] 
            ? COLOR_NAMES[color] 
            : '색상';
        mapHTML += `
            <div class="legend-item" data-region="${region}" style="cursor: pointer;">
                <span class="legend-color" style="background-color: ${color};"></span>
                <span class="legend-label">${region}</span>
                <span class="legend-color-name">${colorName}</span>
            </div>
        `;
    });

    mapHTML += `
                </div>
            </div>
        </div>
    `;

    return mapHTML;
}

function attachMapEventListeners(onRegionClick) {
    // 지역 마커 클릭 이벤트
    document.querySelectorAll('.region-marker').forEach(marker => {
        marker.addEventListener('click', function(e) {
            const region = this.getAttribute('data-region');
            if (region && onRegionClick) {
                onRegionClick(region);
            }
        });

        marker.addEventListener('mouseenter', function() {
            this.setAttribute('r', '3');
            this.style.opacity = '0.8';
            this.style.transform = 'scale(1.2)';
        });

        marker.addEventListener('mouseleave', function() {
            this.setAttribute('r', '2.5');
            this.style.opacity = '1';
            this.style.transform = 'scale(1)';
        });
    });

    // 범례 클릭 이벤트
    document.querySelectorAll('.legend-item').forEach(item => {
        item.addEventListener('click', function() {
            const region = this.getAttribute('data-region');
            if (region && onRegionClick) {
                onRegionClick(region);
            }
        });
    });
}

