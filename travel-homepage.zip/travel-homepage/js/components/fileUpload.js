// File Upload Component

/**
 * 드래그 앤 드롭 파일 업로드 컴포넌트
 */

function createFileUploadComponent(options = {}) {
    const {
        id = 'file-upload',
        accept = 'image/*,video/*',
        multiple = true,
        maxSize = 10 * 1024 * 1024, // 10MB
        onUpload = null
    } = options;

    return `
        <div class="file-upload-container" id="${id}">
            <div class="file-upload-area" id="${id}-area">
                <div class="upload-icon">📁</div>
                <p class="upload-text">파일을 드래그하거나 클릭하여 업로드</p>
                <p class="upload-hint">이미지 또는 동영상 (최대 ${(maxSize / (1024 * 1024)).toFixed(0)}MB)</p>
                <input type="file" 
                       id="${id}-input" 
                       class="file-input" 
                       accept="${accept}" 
                       ${multiple ? 'multiple' : ''} 
                       style="display: none;">
            </div>
            <div class="file-preview-container" id="${id}-preview"></div>
            <div class="upload-progress" id="${id}-progress" style="display: none;">
                <div class="progress-bar">
                    <div class="progress-fill" id="${id}-progress-fill"></div>
                </div>
                <p class="progress-text" id="${id}-progress-text">업로드 중...</p>
            </div>
        </div>
    `;
}

// 파일 업로드 이벤트 리스너 연결
function attachFileUploadListeners(uploadId, options = {}) {
    const {
        maxSize = 10 * 1024 * 1024,
        onUpload = null,
        relatedId = null,
        type = 'general'
    } = options;

    const area = document.getElementById(`${uploadId}-area`);
    const input = document.getElementById(`${uploadId}-input`);
    const preview = document.getElementById(`${uploadId}-preview`);

    if (!area || !input) return;

    // 클릭하여 파일 선택
    area.addEventListener('click', () => input.click());

    // 드래그 앤 드롭
    area.addEventListener('dragover', (e) => {
        e.preventDefault();
        area.classList.add('drag-over');
    });

    area.addEventListener('dragleave', () => {
        area.classList.remove('drag-over');
    });

    area.addEventListener('drop', async (e) => {
        e.preventDefault();
        area.classList.remove('drag-over');

        const files = Array.from(e.dataTransfer.files);
        await handleFiles(files, uploadId, { maxSize, onUpload, relatedId, type, preview });
    });

    // 파일 선택
    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        await handleFiles(files, uploadId, { maxSize, onUpload, relatedId, type, preview });
    });
}

// 파일 처리
async function handleFiles(files, uploadId, options) {
    const { maxSize, onUpload, relatedId, type, preview } = options;
    const validFiles = [];

    // 파일 검증
    for (const file of files) {
        if (file.size > maxSize) {
            toast.error(`${file.name}은(는) 크기가 너무 큽니다 (최대 ${(maxSize / (1024 * 1024)).toFixed(0)}MB)`);
            continue;
        }

        if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
            toast.error(`${file.name}은(는) 지원하지 않는 파일 형식입니다`);
            continue;
        }

        validFiles.push(file);
    }

    if (validFiles.length === 0) return;

    // 진행률 표시
    const progressContainer = document.getElementById(`${uploadId}-progress`);
    const progressFill = document.getElementById(`${uploadId}-progress-fill`);
    const progressText = document.getElementById(`${uploadId}-progress-text`);

    if (progressContainer) {
        progressContainer.style.display = 'block';
    }

    // 파일 업로드
    const uploadedFiles = [];
    for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];

        if (progressFill && progressText) {
            const progress = ((i + 1) / validFiles.length) * 100;
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `업로드 중... (${i + 1}/${validFiles.length})`;
        }

        try {
            const result = await mediaStorage.uploadFile(file, { relatedId, type });
            uploadedFiles.push(result);

            // 미리보기 추가
            if (preview) {
                addFilePreview(preview, result);
            }
        } catch (error) {
            console.error('파일 업로드 실패:', error);
            toast.error(`${file.name} 업로드 실패`);
        }
    }

    // 진행률 숨기기
    if (progressContainer) {
        setTimeout(() => {
            progressContainer.style.display = 'none';
        }, 500);
    }

    // 콜백 호출
    if (onUpload && uploadedFiles.length > 0) {
        onUpload(uploadedFiles);
    }

    toast.success(`${uploadedFiles.length}개 파일이 업로드되었습니다`);
}

// 파일 미리보기 추가
function addFilePreview(container, mediaData) {
    const previewItem = document.createElement('div');
    previewItem.className = 'file-preview-item';
    previewItem.dataset.mediaId = mediaData.id;

    const isImage = mediaData.fileType.startsWith('image/');
    const isVideo = mediaData.fileType.startsWith('video/');

    previewItem.innerHTML = `
        <div class="preview-thumbnail">
            ${isImage ? `<img src="${mediaData.data}" alt="${mediaData.fileName}">` : ''}
            ${isVideo ? `<video src="${mediaData.data}" controls></video>` : ''}
        </div>
        <div class="preview-info">
            <p class="preview-filename">${mediaData.fileName}</p>
            <p class="preview-size">${formatFileSize(mediaData.fileSize)}</p>
        </div>
        <button class="preview-remove" onclick="removeFilePreview(${mediaData.id}, this)">×</button>
    `;

    container.appendChild(previewItem);
}

// 파일 미리보기 제거
async function removeFilePreview(mediaId, button) {
    if (!confirm('이 파일을 삭제하시겠습니까?')) return;

    try {
        await mediaStorage.deleteMedia(mediaId);
        const previewItem = button.closest('.file-preview-item');
        if (previewItem) {
            previewItem.remove();
        }
        toast.success('파일이 삭제되었습니다');
    } catch (error) {
        console.error('파일 삭제 실패:', error);
        toast.error('파일 삭제에 실패했습니다');
    }
}

// 파일 크기 포맷
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}
