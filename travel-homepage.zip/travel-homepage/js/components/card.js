// Card Components

// 여행지 카드
function createDestinationCard(destination) {
    return `
        <div class="card destination-card" data-id="${destination.id}">
            <div class="card-image">
                <img src="${destination.imageUrl}" alt="${escapeHtml(destination.name)}" />
            </div>
            <div class="card-content">
                <h3 class="card-title">${escapeHtml(destination.name)}</h3>
                <p class="card-country" style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">
                    ${escapeHtml(destination.country)}
                </p>
                <div class="rating" style="margin: var(--spacing-sm) 0;">
                    <span class="stars">${renderStars(destination.rating)}</span>
                    <span style="margin-left: var(--spacing-xs); font-weight: var(--font-weight-medium);">
                        ${destination.rating}
                    </span>
                    <span style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">
                        (${destination.reviewCount})
                    </span>
                </div>
                <div class="tags" style="margin: var(--spacing-sm) 0;">
                    ${destination.category.map(cat => `
                        <span class="tag" style="background-color: ${getCategoryColor(cat)}20; color: ${getCategoryColor(cat)};">
                            ${cat}
                        </span>
                    `).join('')}
                </div>
                <div style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin-top: var(--spacing-sm);">
                    ${formatCurrency(destination.estimatedBudget.min)} ~ ${formatCurrency(destination.estimatedBudget.max)}
                </div>
            </div>
            <div class="card-actions">
                <a href="/destination/${destination.id}" data-link class="btn btn-primary">자세히 보기</a>
            </div>
        </div>
    `;
}

// 여행 계획 카드
function createPlanCard(plan) {
    const destination = storage.findById('destinations', plan.destinationId);
    const days = daysBetween(plan.startDate, plan.endDate) + 1;

    return `
        <div class="card plan-card" data-id="${plan.id}">
            <div class="card-content">
                <h3 class="card-title">${escapeHtml(plan.title)}</h3>
                <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin: var(--spacing-sm) 0;">
                    ${destination ? escapeHtml(destination.name) : '알 수 없는 목적지'}
                </p>
                <div style="margin: var(--spacing-sm) 0;">
                    <div style="display: flex; align-items: center; gap: var(--spacing-sm); margin-bottom: var(--spacing-xs);">
                        <span>📅</span>
                        <span>${formatDate(plan.startDate, 'YYYY.MM.DD')} ~ ${formatDate(plan.endDate, 'YYYY.MM.DD')}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: var(--spacing-sm); margin-bottom: var(--spacing-xs);">
                        <span>⏰</span>
                        <span>${days}일</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: var(--spacing-sm); margin-bottom: var(--spacing-xs);">
                        <span>💰</span>
                        <span>${formatCurrency(plan.budget)}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: var(--spacing-sm);">
                        <span>👥</span>
                        <span>${plan.participants}명</span>
                    </div>
                </div>
                <div style="margin-top: var(--spacing-sm);">
                    <span class="tag" style="background-color: ${getStatusColor(plan.status)}20; color: ${getStatusColor(plan.status)};">
                        ${getStatusKorean(plan.status)}
                    </span>
                </div>
            </div>
            <div class="card-actions">
                <button class="btn btn-secondary" onclick="viewPlan('${plan.id}')">상세보기</button>
                <button class="btn btn-warning" onclick="editPlan('${plan.id}')">수정</button>
                <button class="btn btn-error" onclick="deletePlan('${plan.id}')">삭제</button>
            </div>
        </div>
    `;
}

// 후기 카드
function createReviewCard(review) {
    const destination = storage.findById('destinations', review.destinationId);

    return `
        <div class="card review-card" data-id="${review.id}">
            <div class="card-content">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--spacing-sm);">
                    <div>
                        <div class="rating">
                            <span class="stars">${renderStars(review.rating)}</span>
                        </div>
                        <h3 class="card-title" style="margin-top: var(--spacing-xs);">
                            ${escapeHtml(review.title)}
                        </h3>
                    </div>
                </div>
                <p style="color: var(--color-text-secondary); margin: var(--spacing-sm) 0; line-height: 1.6;">
                    ${escapeHtml(review.content.substring(0, 150))}${review.content.length > 150 ? '...' : ''}
                </p>
                <div style="margin: var(--spacing-sm) 0;">
                    <span style="color: var(--color-primary); font-weight: var(--font-weight-medium);">
                        ${destination ? escapeHtml(destination.name) : '알 수 없는 여행지'}
                    </span>
                    <span style="color: var(--color-text-secondary); margin: 0 var(--spacing-xs);">·</span>
                    <span style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">
                        ${formatDate(review.visitDate, 'YYYY.MM.DD')}
                    </span>
                </div>
                <div class="tags">
                    ${review.tags.map(tag => `<span class="tag">#${tag}</span>`).join('')}
                </div>
                <div style="margin-top: var(--spacing-sm); color: var(--color-text-secondary); font-size: var(--font-size-sm);">
                    👍 ${review.helpful}명이 도움을 받았어요
                </div>
            </div>
            <div class="card-actions">
                <button class="btn btn-secondary" onclick="viewReview('${review.id}')">자세히 보기</button>
                <button class="btn btn-primary" onclick="helpfulReview('${review.id}')">도움이 돼요</button>
            </div>
        </div>
    `;
}
