// Navigation Component

function renderNavigation() {
    const nav = document.getElementById('main-nav');

    nav.innerHTML = `
        <div class="nav-container">
            <a href="/" class="nav-logo" data-link>여행 플래너</a>

            <div class="nav-search">
                <input type="text"
                       id="nav-search-input"
                       placeholder="여행지 검색..."
                       autocomplete="off">
            </div>

            <ul class="nav-menu" id="nav-menu">
                <li><a href="/" data-link>홈</a></li>
                <li><a href="/search" data-link>여행지 찾기</a></li>
                <li><a href="/planner" data-link>내 계획</a></li>
                <li><a href="/reviews" data-link>후기</a></li>
            </ul>

            <button class="nav-toggle" id="nav-toggle" aria-label="메뉴 열기">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    `;

    // 검색 기능
    const searchInput = document.getElementById('nav-search-input');
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const query = searchInput.value.trim();
            if (query) {
                router.navigate(`/search?q=${encodeURIComponent(query)}`);
            }
        }
    });

    // 디바운스된 검색 제안 (향후 추가 가능)
    const debouncedSearch = debounce((query) => {
        // 검색 제안 표시 로직 (향후 구현)
    }, 300);

    searchInput.addEventListener('input', (e) => {
        debouncedSearch(e.target.value);
    });

    // 모바일 메뉴 토글
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');

    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        navToggle.classList.toggle('active');
    });

    // 메뉴 항목 클릭 시 메뉴 닫기
    navMenu.addEventListener('click', (e) => {
        if (e.target.matches('[data-link]')) {
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');
        }
    });
}
