// LocalStorage Manager
class StorageManager {
    constructor(storageKey = 'travelApp') {
        this.storageKey = storageKey;
        this.initializeStorage();
    }

    // 초기화
    initializeStorage() {
        if (!localStorage.getItem(this.storageKey)) {
            const initialData = {
                destinations: [],
                travelPlans: [],
                reviews: [],
                recommendations: {
                    popular: [],
                    seasonal: {
                        spring: [],
                        summer: [],
                        fall: [],
                        winter: []
                    },
                    byBudget: {
                        low: [],
                        medium: [],
                        high: []
                    }
                },
                userSettings: {
                    theme: 'light',
                    defaultCurrency: 'KRW',
                    language: 'ko',
                    lastVisited: new Date().toISOString()
                }
            };
            this.saveAll(initialData);
        }
    }

    // 전체 데이터 가져오기
    getAll() {
        try {
            const data = localStorage.getItem(this.storageKey);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Failed to parse localStorage data:', error);
            return null;
        }
    }

    // 전체 데이터 저장
    saveAll(data) {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(data));
        } catch (error) {
            console.error('Failed to save to localStorage:', error);
        }
    }

    // 특정 키 데이터 가져오기
    get(key) {
        const data = this.getAll();
        return data ? data[key] : null;
    }

    // 특정 키 데이터 저장
    set(key, value) {
        const data = this.getAll();
        if (data) {
            data[key] = value;
            this.saveAll(data);
        }
    }

    // 배열에 항목 추가
    add(key, item) {
        const items = this.get(key) || [];
        // ID가 없으면 자동 생성
        if (!item.id) {
            item.id = this.generateId(key);
        }
        items.push(item);
        this.set(key, items);
        return item;
    }

    // 배열에서 항목 업데이트
    update(key, id, updatedItem) {
        const items = this.get(key) || [];
        const index = items.findIndex(item => item.id === id);

        if (index !== -1) {
            items[index] = { ...items[index], ...updatedItem, id };
            this.set(key, items);
            return items[index];
        }
        return null;
    }

    // 배열에서 항목 삭제
    delete(key, id) {
        const items = this.get(key) || [];
        const filtered = items.filter(item => item.id !== id);
        this.set(key, filtered);
        return filtered.length < items.length;
    }

    // ID로 항목 찾기
    findById(key, id) {
        const items = this.get(key) || [];
        return items.find(item => item.id === id);
    }

    // 필터링
    filter(key, predicate) {
        const items = this.get(key) || [];
        return items.filter(predicate);
    }

    // 검색
    search(key, query, fields = ['name', 'title', 'description']) {
        if (!query || query.trim() === '') {
            return this.get(key) || [];
        }

        const items = this.get(key) || [];
        const lowerQuery = query.toLowerCase();

        return items.filter(item => {
            return fields.some(field => {
                const value = this.getNestedValue(item, field);
                return value && String(value).toLowerCase().includes(lowerQuery);
            });
        });
    }

    // 중첩된 속성 값 가져오기
    getNestedValue(obj, path) {
        return path.split('.').reduce((current, prop) => {
            return current ? current[prop] : undefined;
        }, obj);
    }

    // ID 생성
    generateId(prefix = 'item') {
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000);
        return `${prefix}_${timestamp}_${random}`;
    }

    // 데이터 초기화
    reset() {
        localStorage.removeItem(this.storageKey);
        this.initializeStorage();
    }

    // 데이터 내보내기 (JSON)
    exportData() {
        const data = this.getAll();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `travel-data-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    // 데이터 가져오기 (JSON)
    importData(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    this.saveAll(data);
                    resolve(data);
                } catch (error) {
                    reject(error);
                }
            };
            reader.onerror = reject;
            reader.readAsText(file);
        });
    }

    // 통계 가져오기
    getStats() {
        const data = this.getAll();
        return {
            totalDestinations: (data.destinations || []).length,
            totalPlans: (data.travelPlans || []).length,
            totalReviews: (data.reviews || []).length,
            activePlans: (data.travelPlans || []).filter(p => p.status === 'planned').length,
            completedPlans: (data.travelPlans || []).filter(p => p.status === 'completed').length
        };
    }
}

// 전역 스토리지 인스턴스
const storage = new StorageManager();
