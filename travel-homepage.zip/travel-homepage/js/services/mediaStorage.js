// Media Storage Service using IndexedDB

/**
 * IndexedDB를 사용한 미디어 파일 저장소
 * 사진과 동영상을 로컬에 저장하고 관리합니다.
 */

class MediaStorageService {
    constructor() {
        this.dbName = 'TravelMediaDB';
        this.dbVersion = 1;
        this.db = null;
        this.init();
    }

    // IndexedDB 초기화
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // 미디어 파일 저장소
                if (!db.objectStoreNames.contains('media')) {
                    const mediaStore = db.createObjectStore('media', { keyPath: 'id', autoIncrement: true });
                    mediaStore.createIndex('type', 'type', { unique: false });
                    mediaStore.createIndex('relatedId', 'relatedId', { unique: false });
                    mediaStore.createIndex('uploadDate', 'uploadDate', { unique: false });
                }

                // 썸네일 저장소
                if (!db.objectStoreNames.contains('thumbnails')) {
                    db.createObjectStore('thumbnails', { keyPath: 'mediaId' });
                }
            };
        });
    }

    // 파일 업로드
    async uploadFile(file, metadata = {}) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = async (e) => {
                const mediaData = {
                    fileName: file.name,
                    fileType: file.type,
                    fileSize: file.size,
                    data: e.target.result,
                    type: metadata.type || 'general', // plan, review, destination
                    relatedId: metadata.relatedId || null,
                    uploadDate: new Date().toISOString(),
                    description: metadata.description || ''
                };

                try {
                    const id = await this.saveMedia(mediaData);

                    // 이미지인 경우 썸네일 생성
                    if (file.type.startsWith('image/')) {
                        await this.generateThumbnail(id, e.target.result);
                    }

                    resolve({ id, ...mediaData });
                } catch (error) {
                    reject(error);
                }
            };

            reader.onerror = () => reject(reader.error);
            reader.readAsDataURL(file);
        });
    }

    // 미디어 저장
    async saveMedia(mediaData) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['media'], 'readwrite');
            const store = transaction.objectStore('media');
            const request = store.add(mediaData);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 썸네일 생성
    async generateThumbnail(mediaId, dataUrl) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = async () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                // 썸네일 크기 설정 (최대 200x200)
                const maxSize = 200;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxSize) {
                        height = (height * maxSize) / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width = (width * maxSize) / height;
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);

                const thumbnailData = canvas.toDataURL('image/jpeg', 0.7);

                try {
                    await this.saveThumbnail(mediaId, thumbnailData);
                    resolve(thumbnailData);
                } catch (error) {
                    reject(error);
                }
            };
            img.onerror = reject;
            img.src = dataUrl;
        });
    }

    // 썸네일 저장
    async saveThumbnail(mediaId, thumbnailData) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['thumbnails'], 'readwrite');
            const store = transaction.objectStore('thumbnails');
            const request = store.put({ mediaId, data: thumbnailData });

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // 미디어 가져오기
    async getMedia(id) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['media'], 'readonly');
            const store = transaction.objectStore('media');
            const request = store.get(id);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 썸네일 가져오기
    async getThumbnail(mediaId) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['thumbnails'], 'readonly');
            const store = transaction.objectStore('thumbnails');
            const request = store.get(mediaId);

            request.onsuccess = () => resolve(request.result?.data);
            request.onerror = () => reject(request.error);
        });
    }

    // 관련 ID로 미디어 목록 가져오기
    async getMediaByRelatedId(relatedId) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['media'], 'readonly');
            const store = transaction.objectStore('media');
            const index = store.index('relatedId');
            const request = index.getAll(relatedId);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 모든 미디어 가져오기
    async getAllMedia() {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['media'], 'readonly');
            const store = transaction.objectStore('media');
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // 미디어 삭제
    async deleteMedia(id) {
        await this.ensureDB();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['media', 'thumbnails'], 'readwrite');

            const mediaStore = transaction.objectStore('media');
            const thumbnailStore = transaction.objectStore('thumbnails');

            mediaStore.delete(id);
            thumbnailStore.delete(id);

            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }

    // 저장소 통계
    async getStats() {
        await this.ensureDB();

        const allMedia = await this.getAllMedia();
        const totalSize = allMedia.reduce((sum, media) => sum + media.fileSize, 0);
        const imageCount = allMedia.filter(m => m.fileType.startsWith('image/')).length;
        const videoCount = allMedia.filter(m => m.fileType.startsWith('video/')).length;

        return {
            totalFiles: allMedia.length,
            totalSize,
            totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2),
            imageCount,
            videoCount
        };
    }

    // DB 확인
    async ensureDB() {
        if (!this.db) {
            await this.init();
        }
    }
}

// 전역 인스턴스
const mediaStorage = new MediaStorageService();
