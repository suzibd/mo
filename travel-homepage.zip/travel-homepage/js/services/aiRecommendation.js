// AI-based Recommendation Service

/**
 * AI 기반 여행지 추천 시스템
 * 사용자 선호도, 계절, 예산, 테마를 기반으로 여행지를 추천합니다.
 */

class AIRecommendationService {
    constructor() {
        this.userPreferences = this.loadUserPreferences();
    }

    // 사용자 선호도 로드
    loadUserPreferences() {
        const prefs = localStorage.getItem('userPreferences');
        return prefs ? JSON.parse(prefs) : {
            favoriteCategories: [],
            budgetRange: { min: 0, max: 1000000 },
            preferredSeasons: [],
            visitedDestinations: [],
            ratings: {}
        };
    }

    // 사용자 선호도 저장
    saveUserPreferences(preferences) {
        this.userPreferences = { ...this.userPreferences, ...preferences };
        localStorage.setItem('userPreferences', JSON.stringify(this.userPreferences));
    }

    // 메인 추천 함수
    getRecommendations(destinations, options = {}) {
        const {
            season = getCurrentSeason(),
            budget = null,
            theme = null,
            limit = 6
        } = options;

        // 각 여행지에 점수 부여
        const scoredDestinations = destinations.map(dest => ({
            ...dest,
            score: this.calculateScore(dest, { season, budget, theme })
        }));

        // 점수순으로 정렬
        scoredDestinations.sort((a, b) => b.score - a.score);

        // 상위 N개 반환
        return scoredDestinations.slice(0, limit);
    }

    // 여행지 점수 계산
    calculateScore(destination, options) {
        let score = 0;

        // 1. 기본 평점 (30%)
        score += (destination.rating / 5) * 30;

        // 2. 계절 적합도 (20%)
        if (destination.bestSeasons && destination.bestSeasons.includes(options.season)) {
            score += 20;
        }

        // 3. 예산 적합도 (20%)
        if (options.budget) {
            const budgetMatch = this.calculateBudgetMatch(destination, options.budget);
            score += budgetMatch * 20;
        }

        // 4. 테마 적합도 (15%)
        if (options.theme && destination.category.includes(options.theme)) {
            score += 15;
        }

        // 5. 사용자 선호도 (15%)
        const preferenceScore = this.calculatePreferenceScore(destination);
        score += preferenceScore * 15;

        return score;
    }

    // 예산 매칭 점수 계산
    calculateBudgetMatch(destination, budget) {
        const destMin = destination.estimatedBudget.min;
        const destMax = destination.estimatedBudget.max;

        if (budget >= destMin && budget <= destMax) {
            return 1.0; // 완벽한 매칭
        } else if (budget < destMin) {
            const diff = destMin - budget;
            return Math.max(0, 1 - (diff / destMin));
        } else {
            const diff = budget - destMax;
            return Math.max(0, 1 - (diff / budget));
        }
    }

    // 사용자 선호도 점수 계산
    calculatePreferenceScore(destination) {
        let score = 0;
        let factors = 0;

        // 선호 카테고리 매칭
        if (this.userPreferences.favoriteCategories.length > 0) {
            const categoryMatch = destination.category.some(cat =>
                this.userPreferences.favoriteCategories.includes(cat)
            );
            if (categoryMatch) score += 0.5;
            factors++;
        }

        // 이전 평점 고려
        if (this.userPreferences.ratings[destination.id]) {
            score += this.userPreferences.ratings[destination.id] / 5;
            factors++;
        }

        // 방문하지 않은 곳 우선
        if (!this.userPreferences.visitedDestinations.includes(destination.id)) {
            score += 0.3;
            factors++;
        }

        return factors > 0 ? score / factors : 0.5;
    }

    // 계절별 추천
    getSeasonalRecommendations(destinations, season = getCurrentSeason()) {
        return this.getRecommendations(destinations, { season, limit: 6 });
    }

    // 예산별 추천
    getBudgetRecommendations(destinations, budget) {
        return this.getRecommendations(destinations, { budget, limit: 6 });
    }

    // 테마별 추천
    getThemeRecommendations(destinations, theme) {
        return this.getRecommendations(destinations, { theme, limit: 6 });
    }

    // 유사한 여행지 추천 (협업 필터링)
    getSimilarDestinations(destinationId, destinations, limit = 4) {
        const targetDest = destinations.find(d => d.id === destinationId);
        if (!targetDest) return [];

        const scoredDestinations = destinations
            .filter(d => d.id !== destinationId)
            .map(dest => ({
                ...dest,
                similarity: this.calculateSimilarity(targetDest, dest)
            }))
            .sort((a, b) => b.similarity - a.similarity);

        return scoredDestinations.slice(0, limit);
    }

    // 유사도 계산
    calculateSimilarity(dest1, dest2) {
        let similarity = 0;

        // 카테고리 유사도
        const commonCategories = dest1.category.filter(cat =>
            dest2.category.includes(cat)
        );
        similarity += (commonCategories.length / Math.max(dest1.category.length, dest2.category.length)) * 0.4;

        // 예산 유사도
        const budgetDiff = Math.abs(
            (dest1.estimatedBudget.min + dest1.estimatedBudget.max) / 2 -
            (dest2.estimatedBudget.min + dest2.estimatedBudget.max) / 2
        );
        similarity += Math.max(0, 1 - budgetDiff / 1000000) * 0.3;

        // 평점 유사도
        const ratingDiff = Math.abs(dest1.rating - dest2.rating);
        similarity += (1 - ratingDiff / 5) * 0.3;

        return similarity;
    }

    // 사용자 행동 기록
    recordUserAction(action, data) {
        switch (action) {
            case 'visit':
                if (!this.userPreferences.visitedDestinations.includes(data.destinationId)) {
                    this.userPreferences.visitedDestinations.push(data.destinationId);
                }
                break;
            case 'rate':
                this.userPreferences.ratings[data.destinationId] = data.rating;
                break;
            case 'favorite_category':
                if (!this.userPreferences.favoriteCategories.includes(data.category)) {
                    this.userPreferences.favoriteCategories.push(data.category);
                }
                break;
        }
        this.saveUserPreferences(this.userPreferences);
    }

    // 추천 이유 생성
    getRecommendationReason(destination, score) {
        const reasons = [];

        if (destination.rating >= 4.5) {
            reasons.push('⭐ 높은 평점');
        }

        if (destination.bestSeasons && destination.bestSeasons.includes(getCurrentSeason())) {
            reasons.push(`🌸 ${getSeasonKorean(getCurrentSeason())} 추천`);
        }

        const categoryMatch = destination.category.some(cat =>
            this.userPreferences.favoriteCategories.includes(cat)
        );
        if (categoryMatch) {
            reasons.push('❤️ 선호 테마');
        }

        if (score >= 80) {
            reasons.push('🔥 인기 급상승');
        }

        return reasons.length > 0 ? reasons : ['✨ 추천 여행지'];
    }

    // 프롬프트 분석 & 추천
    recommendFromPrompt(destinations, promptText) {
        const criteria = this.analyzePrompt(promptText);
        return {
            recommendations: this.getRecommendations(destinations, criteria),
            analysis: criteria
        };
    }

    // 간단한 텍스트 분석 (NLP Simulation)
    analyzePrompt(text) {
        const criteria = {
            limit: 6
        };

        if (!text) return criteria;
        const lowerText = text.toLowerCase();

        // 1. 계절 감지
        if (lowerText.includes('봄') || lowerText.includes('꽃')) criteria.season = 'spring';
        else if (lowerText.includes('여름') || lowerText.includes('바다') || lowerText.includes('수영')) criteria.season = 'summer';
        else if (lowerText.includes('가을') || lowerText.includes('단풍')) criteria.season = 'fall';
        else if (lowerText.includes('겨울') || lowerText.includes('눈') || lowerText.includes('스키')) criteria.season = 'winter';

        // 2. 예산 감지
        if (lowerText.includes('저렴') || lowerText.includes('싼') || lowerText.includes('가성비')) {
            criteria.budget = 200000; // 저예산 기준
        } else if (lowerText.includes('럭셔리') || lowerText.includes('호화') || lowerText.includes('비싼')) {
            criteria.budget = 1000000; // 고예산 기준
        }

        // 3. 테마 감지
        const themes = {
            '자연': ['자연', '숲', '풍경'],
            '도시': ['도시', '시내', '야경', '쇼핑'],
            '문화': ['문화', '역사', '박물관', '전통'],
            '해변': ['해변', '바다', '해수욕장'],
            '힐링': ['힐링', '휴식', '조용한'],
            '액티비티': ['액티비티', '활동', '스포츠'],
            '음식': ['음식', '맛집', '먹방']
        };

        for (const [key, keywords] of Object.entries(themes)) {
            if (keywords.some(k => lowerText.includes(k))) {
                criteria.theme = key;
                break;
            }
        }

        return criteria;
    }
}


// 전역 인스턴스
const aiRecommendation = new AIRecommendationService();
