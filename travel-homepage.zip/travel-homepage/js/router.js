// SPA Router
class Router {
    constructor() {
        this.routes = {};
        this.currentRoute = null;
    }

    // 라우트 등록
    register(path, handler) {
        this.routes[path] = handler;
    }

    // 페이지 이동
    navigate(path, params = {}) {
        // path에서 쿼리 파라미터 분리
        const [pathOnly, queryString] = path.split('?');
        window.history.pushState({ path: pathOnly, params }, '', path);
        this.render(path, params);
    }

    // 페이지 렌더링
    render(path, params = {}) {
        // 쿼리 파라미터 파싱
        const [pathOnly, queryString] = path.split('?');
        const queryParams = {};
        if (queryString) {
            queryString.split('&').forEach(pair => {
                const [key, value] = pair.split('=');
                if (key) {
                    queryParams[decodeURIComponent(key)] = decodeURIComponent(value || '');
                }
            });
        }

        const matchedRoute = this.matchRoute(pathOnly);

        if (matchedRoute) {
            this.currentRoute = pathOnly;
            const handler = this.routes[matchedRoute.pattern];

            // 네비게이션 활성 상태 업데이트
            this.updateActiveNav(pathOnly);

            // 페이지 핸들러 실행 (쿼리 파라미터 포함)
            if (handler) {
                handler({ ...matchedRoute.params, ...params, ...queryParams });
            }
        } else {
            this.render404();
        }
    }

    // 동적 라우트 매칭
    matchRoute(path) {
        // 정확한 매치 먼저 확인
        if (this.routes[path]) {
            return { pattern: path, params: {} };
        }

        // 동적 라우트 매칭
        for (let pattern in this.routes) {
            const regex = new RegExp('^' + pattern.replace(/:\w+/g, '([^/]+)') + '$');
            const match = path.match(regex);

            if (match) {
                const paramNames = pattern.match(/:\w+/g) || [];
                const params = {};

                paramNames.forEach((name, index) => {
                    params[name.slice(1)] = match[index + 1];
                });

                return { pattern, params };
            }
        }

        return null;
    }

    // 404 페이지
    render404() {
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="container" style="text-align: center; padding: 4rem 0;">
                <h1 style="font-size: 4rem; color: var(--color-text-disabled);">404</h1>
                <p style="font-size: 1.5rem; margin: 1rem 0;">페이지를 찾을 수 없습니다</p>
                <a href="/" data-link class="btn btn-primary">홈으로 돌아가기</a>
            </div>
        `;
    }

    // 네비게이션 활성 상태 업데이트
    updateActiveNav(path) {
        const navLinks = document.querySelectorAll('.nav-menu a');
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === path || (href !== '/' && path.startsWith(href))) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // 뒤로/앞으로 가기 처리
    init() {
        // popstate 이벤트 리스너
        window.addEventListener('popstate', (e) => {
            const path = (e.state?.path || window.location.pathname) + window.location.search;
            const params = e.state?.params || {};
            this.render(path, params);
        });

        // 링크 클릭 인터셉트
        document.addEventListener('click', (e) => {
            const target = e.target.closest('[data-link]');
            if (target) {
                e.preventDefault();
                const path = target.getAttribute('href');
                this.navigate(path);
            }
        });

        // 초기 페이지 렌더링
        const initialPath = window.location.pathname + window.location.search;
        this.render(initialPath);
    }

    // 현재 경로 가져오기
    getCurrentPath() {
        return this.currentRoute;
    }
}

// 전역 라우터 인스턴스
const router = new Router();
