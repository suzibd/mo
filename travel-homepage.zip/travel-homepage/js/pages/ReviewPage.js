// Review Page

function renderReviewPage(params = {}) {
    const app = document.getElementById('app');
    const reviews = storage.get('reviews') || [];
    const destinations = storage.get('destinations') || [];

    app.innerHTML = `
        <div class="review-page">
            <div class="container">
                <div class="review-header">
                    <h1>여행 후기</h1>
                    <button class="btn btn-primary" onclick="showWriteReviewModal()">+ 후기 작성하기</button>
                </div>

                ${reviews.length > 0 ? `
                    <div class="reviews-grid">
                        ${reviews.map(review => createReviewCard(review)).join('')}
                    </div>
                ` : `
                    <div class="no-reviews">
                        <h2>아직 후기가 없습니다</h2>
                        <p>여행 후기를 작성하고 다른 사람들과 공유해보세요!</p>
                        <button class="btn btn-primary btn-large" onclick="showWriteReviewModal()">첫 후기 작성하기</button>
                    </div>
                `}
            </div>
        </div>
    `;
}

function showWriteReviewModal() {
    const destinations = storage.get('destinations') || [];

    const content = `
        <form id="write-review-form" onsubmit="event.preventDefault(); submitReview();">
            <div class="form-group">
                <label class="form-label">여행지</label>
                <select id="review-destination" class="form-select" required>
                    <option value="">선택하세요</option>
                    ${destinations.map(dest => `
                        <option value="${dest.id}">${escapeHtml(dest.name)}</option>
                    `).join('')}
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">평점</label>
                <div class="rating-input">
                    ${[5, 4, 3, 2, 1].map(num => `
                        <input type="radio" id="rating-${num}" name="rating" value="${num}" ${num === 5 ? 'checked' : ''}>
                        <label for="rating-${num}">★</label>
                    `).join('')}
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">제목</label>
                <input type="text" id="review-title" class="form-input" required placeholder="후기 제목을 입력하세요">
            </div>

            <div class="form-group">
                <label class="form-label">내용</label>
                <textarea id="review-content" class="form-textarea" required placeholder="여행 경험을 자세히 공유해주세요"></textarea>
            </div>

            <div class="form-group">
                <label class="form-label">방문 날짜</label>
                <input type="date" id="review-visit-date" class="form-input" required>
            </div>

            <div class="form-group">
                <label class="form-label">태그 (쉼표로 구분)</label>
                <input type="text" id="review-tags" class="form-input" placeholder="예: 가족여행, 힐링, 자연">
            </div>
        </form>
    `;

    modal.show('후기 작성하기', content, [
        {
            label: '취소',
            className: 'btn-secondary',
            onClick: 'modal.close()'
        },
        {
            label: '작성',
            className: 'btn-primary',
            onClick: 'document.getElementById(\'write-review-form\').requestSubmit()'
        }
    ]);
}

function submitReview() {
    const destinationId = document.getElementById('review-destination').value;
    const rating = parseInt(document.querySelector('input[name="rating"]:checked').value);
    const title = document.getElementById('review-title').value;
    const content = document.getElementById('review-content').value;
    const visitDate = document.getElementById('review-visit-date').value;
    const tagsInput = document.getElementById('review-tags').value;

    // 태그 파싱
    const tags = tagsInput
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);

    const review = {
        id: storage.generateId('review'),
        destinationId,
        planId: null,
        title,
        content,
        rating,
        visitDate,
        createdAt: new Date().toISOString(),
        photos: [],
        tags,
        helpful: 0
    };

    storage.add('reviews', review);

    // 여행지 평점 및 후기 수 업데이트
    updateDestinationRating(destinationId);

    modal.close();
    toast.success('후기가 작성되었습니다');
    renderReviewPage();
}

function updateDestinationRating(destinationId) {
    const destination = storage.findById('destinations', destinationId);
    if (!destination) return;

    const reviews = storage.filter('reviews', r => r.destinationId === destinationId);

    if (reviews.length > 0) {
        const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
        const roundedRating = Math.round(avgRating * 10) / 10;

        storage.update('destinations', destinationId, {
            rating: roundedRating,
            reviewCount: reviews.length
        });
    }
}

function viewReview(reviewId) {
    const review = storage.findById('reviews', reviewId);
    if (!review) {
        toast.error('후기를 찾을 수 없습니다');
        return;
    }

    const destination = storage.findById('destinations', review.destinationId);

    const content = `
        <div class="review-detail">
            <div class="rating" style="margin-bottom: var(--spacing-md);">
                <span class="stars" style="font-size: var(--font-size-2xl);">${renderStars(review.rating)}</span>
            </div>

            <div class="review-info">
                <p><strong>여행지:</strong> ${destination ? escapeHtml(destination.name) : '알 수 없음'}</p>
                <p><strong>방문 날짜:</strong> ${formatDate(review.visitDate, 'YYYY.MM.DD')}</p>
                <p><strong>작성 날짜:</strong> ${formatDate(review.createdAt, 'YYYY.MM.DD')}</p>
            </div>

            <div class="review-content" style="margin: var(--spacing-lg) 0;">
                <p style="line-height: 1.8; white-space: pre-wrap;">${escapeHtml(review.content)}</p>
            </div>

            ${review.tags.length > 0 ? `
                <div class="tags">
                    ${review.tags.map(tag => `<span class="tag">#${tag}</span>`).join('')}
                </div>
            ` : ''}

            <div style="margin-top: var(--spacing-lg); padding-top: var(--spacing-lg); border-top: 1px solid var(--color-border);">
                <p style="color: var(--color-text-secondary);">👍 ${review.helpful}명이 이 후기가 도움이 되었다고 평가했습니다</p>
            </div>
        </div>
    `;

    modal.show(escapeHtml(review.title), content, [
        {
            label: '도움이 돼요',
            className: 'btn-primary',
            onClick: `helpfulReview('${reviewId}'); modal.close()`
        },
        {
            label: '닫기',
            className: 'btn-secondary',
            onClick: 'modal.close()'
        }
    ]);
}

function helpfulReview(reviewId) {
    const review = storage.findById('reviews', reviewId);
    if (review) {
        storage.update('reviews', reviewId, {
            helpful: review.helpful + 1
        });
        toast.success('도움이 된다고 표시했습니다');
        renderReviewPage();
    }
}
