// Home Page

// 선택된 색상 상태 관리
let selectedColor = null;

function renderHomePage() {
    const app = document.getElementById('app');
    const destinations = storage.get('destinations') || [];
    const reviews = storage.get('reviews') || [];
    const recommendations = storage.get('recommendations') || {};
    const currentSeason = getCurrentSeason();

    // 선택된 색상에 따른 여행지 (선택되지 않았으면 빈 배열)
    let selectedColorDestinations = [];
    let colorName = '';
    let regionsForColor = [];

    if (selectedColor) {
        colorName = getColorName(selectedColor);
        regionsForColor = getRegionsByColor(selectedColor);
        selectedColorDestinations = filterDestinationsByRegions(destinations, regionsForColor);
    }

    // 인기 여행지 (추천 또는 상위 3개)
    const popularDestinations = recommendations.popular
        ? recommendations.popular.map(id => storage.findById('destinations', id)).filter(Boolean)
        : destinations.slice(0, 3);

    // 현재 계절 추천 (AI 기반)
    const seasonalDestinations = aiRecommendation.getSeasonalRecommendations(destinations);

    // AI 맞춤 추천
    const aiCustomDestinations = aiRecommendation.getRecommendations(destinations, { limit: 3 });

    // 최근 후기 (상위 3개)
    const recentReviews = reviews.sort((a, b) =>
        new Date(b.createdAt) - new Date(a.createdAt)
    ).slice(0, 3);

    app.innerHTML = `
        <div class="home-page">
            <!-- 히어로 섹션 -->
            <section class="hero-section">
                <div class="container">
                    <h1 class="hero-title">나만의 완벽한 여행을 계획하세요</h1>
                    <p class="hero-subtitle">전국의 아름다운 여행지를 검색하고, 일정을 만들고, 후기를 공유하세요</p>
                    <div class="hero-actions">
                        <a href="/search" data-link class="btn btn-primary btn-large">여행지 둘러보기</a>
                        <a href="/planner" data-link class="btn btn-secondary btn-large">여행 계획 만들기</a>
                    </div>
                </div>
            </section>

            <!-- 색상 선택 섹션 -->
            <section class="section color-picker-section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">색상으로 여행지 추천받기</h2>
                        <p class="section-subtitle">버튼을 클릭하면 색상을 선택할 수 있는 팝업이 열립니다</p>
                    </div>
                    
                    <div class="color-picker-container">
                        <button class="btn btn-primary btn-large color-picker-button" onclick="selectRandomColor()">
                            ${selectedColor
            ? `<span class="selected-color-info">
                                    <span class="color-badge-small" style="background-color: ${selectedColor};"></span>
                                    ${colorName}색 - ${regionsForColor.join(', ')}
                                </span>`
            : '🎲 랜덤 색상 선택하기'
        }
                        </button>
                        ${selectedColor ? `<button class="btn btn-secondary" onclick="resetColorSelection()" style="margin-left: var(--spacing-sm);">초기화</button>` : ''}
                    </div>

                    ${selectedColor && selectedColorDestinations.length > 0
            ? `<div class="color-destination-results" style="background: linear-gradient(135deg, ${selectedColor}15 0%, ${selectedColor}05 100%); margin-top: var(--spacing-xl); padding: var(--spacing-xl); border-radius: var(--radius-lg);">
                            <div class="section-header">
                                <div>
                                    <h3 class="section-title" style="font-size: var(--font-size-xl);">
                                        <span class="color-badge" style="background-color: ${selectedColor};"></span>
                                        ${colorName}색 여행지 추천
                                    </h3>
                                    <p class="color-description">${regionsForColor.join(', ')} 지역</p>
                                </div>
                            </div>
                            <div class="grid grid-3">
                                ${selectedColorDestinations.slice(0, 3).map(dest => createDestinationCard(dest)).join('')}
                            </div>
                            <div class="text-center" style="margin-top: var(--spacing-xl);">
                                <a href="/search?color=${encodeURIComponent(selectedColor)}" data-link class="btn btn-primary">${colorName}색 여행지 더 보기 →</a>
                            </div>
                        </div>`
            : selectedColor
                ? `<div class="no-destinations" style="margin-top: var(--spacing-xl); padding: var(--spacing-xl); background: linear-gradient(135deg, ${selectedColor}15 0%, ${selectedColor}05 100%); border-radius: var(--radius-lg);">
                                <p>${colorName}색 지역에 해당하는 여행지가 없습니다.</p>
                            </div>`
                : ''
        }
                </div>
            </section>

            <!-- 한국 지도 섹션 -->
            <section class="section korea-map-section" style="background-color: var(--color-surface);">
                <div class="container">
                    <div class="collapsible-section">
                        <button class="collapsible-header" onclick="toggleMapSection()">
                            <h2 class="section-title">지도에서 지역 선택하기</h2>
                            <span class="collapsible-icon" id="map-section-icon">▼</span>
                        </button>
                        <div class="collapsible-content" id="map-section-content" style="display: none;">
                            ${createKoreaMap((regionName) => {
            showRegionInfo(regionName);
        })}
                        </div>
                    </div>
                </div>
            </section>

            <!-- AI 여행 코디네이터 (Interactive) -->
            <section class="section ai-assistant-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 60px 0;">
                <div class="container">
                    <div class="section-header text-center text-white" style="margin-bottom: 40px;">
                        <h2 class="section-title" style="color: white; border-bottom-color: rgba(255,255,255,0.3); display: inline-block;">✨ AI 여행 코디네이터</h2>
                        <p class="section-subtitle" style="color: rgba(255,255,255,0.9); margin-top: 15px;">원하시는 여행 스타일을 말씀해주세요. AI가 최고의 여행지를 추천해드립니다.</p>
                    </div>
                    
                    <div class="ai-input-container" style="max-width: 700px; margin: 0 auto;">
                        <div class="input-group" style="position: relative; display: flex; gap: 10px; background: white; padding: 8px; border-radius: 50px; box-shadow: 0 10px 25px rgba(0,0,0,0.2);">
                            <input type="text" id="ai-prompt-input" placeholder="예: 여름에 가기 좋은 조용한 바다 여행지 추천해줘" 
                                style="flex: 1; border: none; padding: 15px 25px; font-size: 16px; border-radius: 30px; outline: none; width: 100%;"
                                onkeypress="if(event.key === 'Enter') handleAIPrompt()">
                            <button class="btn btn-primary" onclick="handleAIPrompt()" style="border-radius: 30px; padding: 12px 35px; font-weight: bold; white-space: nowrap;">
                                🤖 추천받기
                            </button>
                        </div>
                        <div class="ai-tags" style="margin-top: 20px; display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                            <span style="background: rgba(255,255,255,0.2); padding: 8px 18px; border-radius: 20px; font-size: 14px; cursor: pointer; transition: background 0.2s;" onclick="setPrompt('가을 단풍 여행지 추천')" onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">#가을단풍</span>
                            <span style="background: rgba(255,255,255,0.2); padding: 8px 18px; border-radius: 20px; font-size: 14px; cursor: pointer; transition: background 0.2s;" onclick="setPrompt('10만원대 가성비 맛집 여행')" onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">#가성비맛집</span>
                            <span style="background: rgba(255,255,255,0.2); padding: 8px 18px; border-radius: 20px; font-size: 14px; cursor: pointer; transition: background 0.2s;" onclick="setPrompt('조용한 힐링 여행')" onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">#힐링휴식</span>
                        </div>
                    </div>

                    <div id="ai-results-container" style="margin-top: 50px; display: none; animation: fadeIn 0.5s ease-out;">
                        <div class="section-header text-center">
                            <h3 class="result-title text-white" style="font-size: 1.5rem; margin-bottom: 10px;">🎯 이런 여행지는 어떠세요?</h3>
                            <p id="ai-analysis-text" style="color: rgba(255,255,255,0.9); margin-bottom: 30px; font-size: 1.1rem;"></p>
                        </div>
                        <div id="ai-recommendations-grid" class="grid grid-3">
                            <!-- 결과 카드 -->
                        </div>
                    </div>
                </div>
            </section>

            <!-- 인기 여행지 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">인기 여행지</h2>
                        <a href="/search" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${popularDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 계절별 추천 -->
            <section class="section" style="background-color: var(--color-surface);">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">${getSeasonKorean(currentSeason)} 추천 여행지</h2>
                    </div>
                    <div class="grid grid-3">
                        ${seasonalDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 최근 후기 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">최근 여행 후기</h2>
                        <a href="/reviews" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${recentReviews.map(review => createReviewCard(review)).join('')}
                    </div>
                </div>
            </section>

            <!-- 나의 여행 갤러리 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">나의 여행 갤러리</h2>
                        <button class="btn btn-secondary btn-sm" onclick="showFileUploadModal()">📷 사진 업로드</button>
                    </div>
                    <div id="home-gallery-grid" class="grid grid-4" style="min-height: 200px;">
                        <!-- 갤러리 이미지가 로드될 공간 -->
                        <div class="loading-spinner"></div>
                    </div>
                    <div class="text-center" style="margin-top: var(--spacing-lg);">
                        <a href="/gallery" data-link class="btn btn-outline">갤러리 전체보기 →</a>
                    </div>
                </div>
            </section>

            <!-- CTA 섹션 -->
            <section class="cta-section">
                <div class="container text-center">
                    <h2>지금 바로 여행 계획을 시작하세요</h2>
                    <p>여행지를 검색하고, 나만의 여행 일정을 만들어보세요</p>
                    <a href="/planner" data-link class="btn btn-primary btn-large">여행 계획 만들기</a>
                </div>
            </section>
        </div>
    `;

    // 지도 이벤트 리스너 추가
    setTimeout(() => {
        attachMapEventListeners((regionName) => {
            const color = getColorByRegion(regionName);
            if (color) {
                selectRegionColor(color);
            }
        });

        // 갤러리 이미지 로드
        loadHomeGallery();
    }, 0);
}

// 홈 갤러리 로드 함수
async function loadHomeGallery() {
    const galleryGrid = document.getElementById('home-gallery-grid');
    if (!galleryGrid) return;

    try {
        const mediaList = await mediaStorage.getAllMedia();
        const recentMedia = mediaList.sort((a, b) => b.createdAt - a.createdAt).slice(0, 4);

        if (recentMedia.length === 0) {
            galleryGrid.innerHTML = `
                <div class="empty-state" style="grid-column: 1 / -1; padding: 40px 0;">
                    <p style="color: var(--color-text-secondary); margin-bottom: 20px;">아직 업로드된 사진이 없습니다</p>
                    <button class="btn btn-primary" onclick="showFileUploadModal()">첫 사진 업로드하기</button>
                </div>
            `;
            // grid-4 클래스 제거하고 flex로 변경하여 중앙 정렬
            galleryGrid.className = 'd-flex justify-center align-center';
        } else {
            galleryGrid.className = 'grid grid-4';
            galleryGrid.innerHTML = recentMedia.map(media => `
                <div class="gallery-item" onclick="openLightbox('${media.id}')" style="aspect-ratio: 1; overflow: hidden; border-radius: 8px; cursor: pointer; position: relative;">
                    <img src="${media.thumbnail || media.data}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    ${media.type.startsWith('video') ? '<div class="video-indicator" style="position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.5); color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">▶</div>' : ''}
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Failed to load gallery:', error);
        galleryGrid.innerHTML = '<p class="error-message">갤러리를 불러오는 중 오류가 발생했습니다.</p>';
    }
}

// 파일 업로드 모달 표시
function showFileUploadModal() {
    const content = `
        <div id="upload-component-container"></div>
    `;

    modal.show('여행 추억 업로드', content, [], 'normal');

    // 모달이 렌더링된 후 업로드 컴포넌트 초기화
    setTimeout(() => {
        const container = document.getElementById('upload-component-container');
        if (container && typeof FileUploadComponent !== 'undefined') {
            new FileUploadComponent(container, {
                onUploadComplete: () => {
                    modal.close();
                    loadHomeGallery(); // 갤러리 새로고침
                    // 토스트 메시지 표시 (구현되어 있다면)
                    if (window.showToast) showToast('파일이 성공적으로 업로드되었습니다!');
                }
            });
        }
    }, 100);
}

// 랜덤 색상 선택 함수
function selectRandomColor() {
    selectedColor = getRandomColor();
    renderHomePage();

    // 선택된 색상에 맞는 여행지 섹션으로 부드럽게 스크롤
    setTimeout(() => {
        const colorSection = document.querySelector('.color-destination-results, .no-destinations');
        if (colorSection) {
            colorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 색상 선택 초기화 함수
function resetColorSelection() {
    selectedColor = null;
    renderHomePage();

    // 색상 선택 칸으로 부드럽게 스크롤
    setTimeout(() => {
        const pickerSection = document.querySelector('.color-picker-section');
        if (pickerSection) {
            pickerSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 색상 선택 모달 표시
function showColorPickerModal() {
    const colorPickerContent = `
        <div class="color-picker-modal">
            <p class="modal-description">색상을 클릭하면 랜덤으로 선택되어 해당 색상의 지역으로 안내해드립니다</p>
            <div class="color-picker-grid">
                ${typeof AVAILABLE_COLORS !== 'undefined' ? AVAILABLE_COLORS.map(color => {
        const colorName = getColorName(color);
        const regions = getRegionsByColor(color);
        return `
                        <div class="color-picker-item" onclick="selectColorFromModal('${color}'); modal.close();" style="cursor: pointer;">
                            <div class="color-box" style="background-color: ${color};"></div>
                            <div class="color-info">
                                <span class="color-item-name">${colorName}</span>
                                <span class="color-item-regions">${regions.join(', ')}</span>
                            </div>
                        </div>
                    `;
    }).join('') : '<p>색상 데이터를 불러올 수 없습니다.</p>'}
            </div>
            <div class="modal-footer-actions">
                <button class="btn btn-secondary" onclick="modal.close()">취소</button>
            </div>
        </div>
    `;

    modal.show('색상 선택', colorPickerContent, [], 'small');
}

// 모달에서 색상 선택
function selectColorFromModal(color) {
    selectedColor = color;
    renderHomePage();

    // 선택된 색상 결과 섹션으로 스크롤
    setTimeout(() => {
        const resultsSection = document.querySelector('.color-destination-results, .no-destinations');
        if (resultsSection) {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 지도 섹션 토글
let mapSectionExpanded = false;
function toggleMapSection() {
    mapSectionExpanded = !mapSectionExpanded;
    const content = document.getElementById('map-section-content');
    const icon = document.getElementById('map-section-icon');

    if (content && icon) {
        if (mapSectionExpanded) {
            content.style.display = 'block';
            icon.textContent = '▲';
            icon.style.transform = 'rotate(0deg)';
            // 지도 이벤트 리스너 다시 추가
            setTimeout(() => {
                attachMapEventListeners((regionName) => {
                    const color = getColorByRegion(regionName);
                    if (color) {
                        selectRegionColor(color);
                        toggleMapSection(); // 선택 후 자동으로 접기
                    }
                });
            }, 0);
        } else {
            content.style.display = 'none';
            icon.textContent = '▼';
            icon.style.transform = 'rotate(0deg)';
        }
    }
}

// 지역 색상 선택 함수 (지도에서 사용)
// 지역 색상 선택 함수 (지도에서 사용)
function selectRegionColor(color) {
    selectedColor = color;
    renderHomePage();

    // 색상 선택 결과 섹션으로 스크롤
    setTimeout(() => {
        const resultsSection = document.querySelector('.color-destination-results, .no-destinations');
        if (resultsSection) {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// AI 프롬프트 처리
function handleAIPrompt() {
    const input = document.getElementById('ai-prompt-input');
    const resultsContainer = document.getElementById('ai-results-container');
    const resultsGrid = document.getElementById('ai-recommendations-grid');
    const analysisText = document.getElementById('ai-analysis-text');

    if (!input || !input.value.trim()) {
        alert('여행 스타일을 입력해주세요!');
        return;
    }

    const prompt = input.value;
    const destinations = storage.get('destinations') || [];

    // 로딩 표시
    resultsContainer.style.display = 'block';
    resultsGrid.innerHTML = '<div class="loading-spinner" style="grid-column: 1/-1; margin: 40px auto; border-color: rgba(255,255,255,0.3); border-top-color: white;"></div>';

    // AI 시뮬레이션 지연 효과
    setTimeout(() => {
        const result = aiRecommendation.recommendFromPrompt(destinations, prompt);

        // 분석 결과 텍스트 생성
        const analysis = result.analysis;
        let analysisMsg = [];
        if (analysis.season) analysisMsg.push(`${getSeasonKorean(analysis.season)}`);
        if (analysis.theme) analysisMsg.push(`${analysis.theme} 테마`);
        if (analysis.budget) analysisMsg.push(`${getBudgetLevelKorean(getBudgetLevel(analysis.budget))} 예산`);

        const keywords = analysisMsg.join(', ');
        analysisText.innerHTML = keywords
            ? `<strong>"${keywords}"</strong> 키워드로 분석했습니다.`
            : `<strong>"${prompt}"</strong>에 대한 추천 결과입니다.`;

        // 결과 렌더링
        if (result.recommendations.length > 0) {
            resultsGrid.innerHTML = result.recommendations.map(dest => createRecommendationCard(dest)).join('');
        } else {
            resultsGrid.innerHTML = `
                <div class="no-results text-center" style="grid-column: 1/-1; padding: 30px; color: rgba(255,255,255,0.9);">
                    <p>조건에 맞는 여행지를 찾지 못했습니다. 😢<br>다른 검색어로 다시 시도해보세요.</p>
                </div>
            `;
        }
    }, 800);
}

// 프롬프트 설정 (태그 클릭 시)
function setPrompt(text) {
    const input = document.getElementById('ai-prompt-input');
    if (input) {
        input.value = text;
        handleAIPrompt();
    }
}


