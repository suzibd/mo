// Home Page

function renderHomePage() {
    const app = document.getElementById('app');
    const destinations = storage.get('destinations') || [];
    const reviews = storage.get('reviews') || [];
    const recommendations = storage.get('recommendations') || {};

    // 인기 여행지 (추천 또는 상위 3개)
    const popularDestinations = recommendations.popular
        ? recommendations.popular.map(id => storage.findById('destinations', id)).filter(Boolean)
        : destinations.slice(0, 3);

    // 현재 계절 추천
    const currentSeason = getCurrentSeason();
    const seasonalDestinations = recommendations.seasonal?.[currentSeason]
        ? recommendations.seasonal[currentSeason].map(id => storage.findById('destinations', id)).filter(Boolean)
        : destinations.slice(3, 6);

    // 최근 후기 (상위 3개)
    const recentReviews = reviews.sort((a, b) =>
        new Date(b.createdAt) - new Date(a.createdAt)
    ).slice(0, 3);

    app.innerHTML = `
        <div class="home-page">
            <!-- 히어로 섹션 -->
            <section class="hero-section">
                <div class="container">
                    <h1 class="hero-title">나만의 완벽한 여행을 계획하세요</h1>
                    <p class="hero-subtitle">전국의 아름다운 여행지를 검색하고, 일정을 만들고, 후기를 공유하세요</p>
                    <div class="hero-actions">
                        <a href="/search" data-link class="btn btn-primary btn-large">여행지 둘러보기</a>
                        <a href="/planner" data-link class="btn btn-secondary btn-large">여행 계획 만들기</a>
                    </div>
                </div>
            </section>

            <!-- 인기 여행지 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">인기 여행지</h2>
                        <a href="/search" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${popularDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 계절별 추천 -->
            <section class="section" style="background-color: var(--color-surface);">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">${getSeasonKorean(currentSeason)} 추천 여행지</h2>
                    </div>
                    <div class="grid grid-3">
                        ${seasonalDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 최근 후기 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">최근 여행 후기</h2>
                        <a href="/reviews" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${recentReviews.map(review => createReviewCard(review)).join('')}
                    </div>
                </div>
            </section>

            <!-- CTA 섹션 -->
            <section class="cta-section">
                <div class="container text-center">
                    <h2>지금 바로 여행 계획을 시작하세요</h2>
                    <p>여행지를 검색하고, 나만의 여행 일정을 만들어보세요</p>
                    <a href="/planner" data-link class="btn btn-primary btn-large">여행 계획 만들기</a>
                </div>
            </section>
        </div>
    `;
}
