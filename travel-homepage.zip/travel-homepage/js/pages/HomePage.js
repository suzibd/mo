// Home Page

// 선택된 색상 상태 관리
let selectedColor = null;

function renderHomePage() {
    const app = document.getElementById('app');
    const destinations = storage.get('destinations') || [];
    const reviews = storage.get('reviews') || [];
    const recommendations = storage.get('recommendations') || {};

    // 선택된 색상에 따른 여행지 (선택되지 않았으면 빈 배열)
    let selectedColorDestinations = [];
    let colorName = '';
    let regionsForColor = [];
    
    if (selectedColor) {
        colorName = getColorName(selectedColor);
        regionsForColor = getRegionsByColor(selectedColor);
        selectedColorDestinations = filterDestinationsByRegions(destinations, regionsForColor);
    }

    // 인기 여행지 (추천 또는 상위 3개)
    const popularDestinations = recommendations.popular
        ? recommendations.popular.map(id => storage.findById('destinations', id)).filter(Boolean)
        : destinations.slice(0, 3);

    // 현재 계절 추천
    const currentSeason = getCurrentSeason();
    const seasonalDestinations = recommendations.seasonal?.[currentSeason]
        ? recommendations.seasonal[currentSeason].map(id => storage.findById('destinations', id)).filter(Boolean)
        : destinations.slice(3, 6);

    // 최근 후기 (상위 3개)
    const recentReviews = reviews.sort((a, b) =>
        new Date(b.createdAt) - new Date(a.createdAt)
    ).slice(0, 3);

    app.innerHTML = `
        <div class="home-page">
            <!-- 히어로 섹션 -->
            <section class="hero-section">
                <div class="container">
                    <h1 class="hero-title">나만의 완벽한 여행을 계획하세요</h1>
                    <p class="hero-subtitle">전국의 아름다운 여행지를 검색하고, 일정을 만들고, 후기를 공유하세요</p>
                    <div class="hero-actions">
                        <a href="/search" data-link class="btn btn-primary btn-large">여행지 둘러보기</a>
                        <a href="/planner" data-link class="btn btn-secondary btn-large">여행 계획 만들기</a>
                    </div>
                </div>
            </section>

            <!-- 색상 선택 섹션 -->
            <section class="section color-picker-section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">색상으로 여행지 추천받기</h2>
                        <p class="section-subtitle">버튼을 클릭하면 색상을 선택할 수 있는 팝업이 열립니다</p>
                    </div>
                    
                    <div class="color-picker-container">
                        <button class="btn btn-primary btn-large color-picker-button" onclick="showColorPickerModal()">
                            ${selectedColor 
                                ? `<span class="selected-color-info">
                                    <span class="color-badge-small" style="background-color: ${selectedColor};"></span>
                                    ${colorName}색 - ${regionsForColor.join(', ')}
                                </span>`
                                : '🎨 색상 선택하기'
                            }
                        </button>
                        ${selectedColor ? `<button class="btn btn-secondary" onclick="resetColorSelection()" style="margin-left: var(--spacing-sm);">초기화</button>` : ''}
                    </div>

                    ${selectedColor && selectedColorDestinations.length > 0 
                        ? `<div class="color-destination-results" style="background: linear-gradient(135deg, ${selectedColor}15 0%, ${selectedColor}05 100%); margin-top: var(--spacing-xl); padding: var(--spacing-xl); border-radius: var(--radius-lg);">
                            <div class="section-header">
                                <div>
                                    <h3 class="section-title" style="font-size: var(--font-size-xl);">
                                        <span class="color-badge" style="background-color: ${selectedColor};"></span>
                                        ${colorName}색 여행지 추천
                                    </h3>
                                    <p class="color-description">${regionsForColor.join(', ')} 지역</p>
                                </div>
                            </div>
                            <div class="grid grid-3">
                                ${selectedColorDestinations.slice(0, 3).map(dest => createDestinationCard(dest)).join('')}
                            </div>
                            <div class="text-center" style="margin-top: var(--spacing-xl);">
                                <a href="/search?color=${encodeURIComponent(selectedColor)}" data-link class="btn btn-primary">${colorName}색 여행지 더 보기 →</a>
                            </div>
                        </div>`
                        : selectedColor 
                            ? `<div class="no-destinations" style="margin-top: var(--spacing-xl); padding: var(--spacing-xl); background: linear-gradient(135deg, ${selectedColor}15 0%, ${selectedColor}05 100%); border-radius: var(--radius-lg);">
                                <p>${colorName}색 지역에 해당하는 여행지가 없습니다.</p>
                            </div>`
                            : ''
                    }
                </div>
            </section>

            <!-- 한국 지도 섹션 -->
            <section class="section korea-map-section" style="background-color: var(--color-surface);">
                <div class="container">
                    <div class="collapsible-section">
                        <button class="collapsible-header" onclick="toggleMapSection()">
                            <h2 class="section-title">지도에서 지역 선택하기</h2>
                            <span class="collapsible-icon" id="map-section-icon">▼</span>
                        </button>
                        <div class="collapsible-content" id="map-section-content" style="display: none;">
                            ${createKoreaMap((regionName) => {
                                const color = getColorByRegion(regionName);
                                if (color) {
                                    selectRegionColor(color);
                                    toggleMapSection(); // 선택 후 자동으로 접기
                                }
                            })}
                        </div>
                    </div>
                </div>
            </section>

            <!-- 인기 여행지 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">인기 여행지</h2>
                        <a href="/search" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${popularDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 계절별 추천 -->
            <section class="section" style="background-color: var(--color-surface);">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">${getSeasonKorean(currentSeason)} 추천 여행지</h2>
                    </div>
                    <div class="grid grid-3">
                        ${seasonalDestinations.map(dest => createDestinationCard(dest)).join('')}
                    </div>
                </div>
            </section>

            <!-- 최근 후기 -->
            <section class="section">
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title">최근 여행 후기</h2>
                        <a href="/reviews" data-link class="section-link">전체 보기 →</a>
                    </div>
                    <div class="grid grid-3">
                        ${recentReviews.map(review => createReviewCard(review)).join('')}
                    </div>
                </div>
            </section>

            <!-- CTA 섹션 -->
            <section class="cta-section">
                <div class="container text-center">
                    <h2>지금 바로 여행 계획을 시작하세요</h2>
                    <p>여행지를 검색하고, 나만의 여행 일정을 만들어보세요</p>
                    <a href="/planner" data-link class="btn btn-primary btn-large">여행 계획 만들기</a>
                </div>
            </section>
        </div>
    `;

    // 지도 이벤트 리스너 추가
    setTimeout(() => {
        attachMapEventListeners((regionName) => {
            const color = getColorByRegion(regionName);
            if (color) {
                selectRegionColor(color);
            }
        });
    }, 0);
}

// 랜덤 색상 선택 함수
function selectRandomColor() {
    selectedColor = getRandomColor();
    renderHomePage();
    
    // 선택된 색상에 맞는 여행지 섹션으로 부드럽게 스크롤
    setTimeout(() => {
        const colorSection = document.querySelector('.color-destination-results, .no-destinations');
        if (colorSection) {
            colorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 색상 선택 초기화 함수
function resetColorSelection() {
    selectedColor = null;
    renderHomePage();
    
    // 색상 선택 칸으로 부드럽게 스크롤
    setTimeout(() => {
        const pickerSection = document.querySelector('.color-picker-section');
        if (pickerSection) {
            pickerSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 색상 선택 모달 표시
function showColorPickerModal() {
    const colorPickerContent = `
        <div class="color-picker-modal">
            <p class="modal-description">색상을 클릭하면 랜덤으로 선택되어 해당 색상의 지역으로 안내해드립니다</p>
            <div class="color-picker-grid">
                ${typeof AVAILABLE_COLORS !== 'undefined' ? AVAILABLE_COLORS.map(color => {
                    const colorName = getColorName(color);
                    const regions = getRegionsByColor(color);
                    return `
                        <div class="color-picker-item" onclick="selectColorFromModal('${color}'); modal.close();" style="cursor: pointer;">
                            <div class="color-box" style="background-color: ${color};"></div>
                            <div class="color-info">
                                <span class="color-item-name">${colorName}</span>
                                <span class="color-item-regions">${regions.join(', ')}</span>
                            </div>
                        </div>
                    `;
                }).join('') : '<p>색상 데이터를 불러올 수 없습니다.</p>'}
            </div>
            <div class="modal-footer-actions">
                <button class="btn btn-secondary" onclick="modal.close()">취소</button>
            </div>
        </div>
    `;
    
    modal.show('색상 선택', colorPickerContent, [], 'small');
}

// 모달에서 색상 선택
function selectColorFromModal(color) {
    selectedColor = color;
    renderHomePage();
    
    // 선택된 색상 결과 섹션으로 스크롤
    setTimeout(() => {
        const resultsSection = document.querySelector('.color-destination-results, .no-destinations');
        if (resultsSection) {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// 지도 섹션 토글
let mapSectionExpanded = false;
function toggleMapSection() {
    mapSectionExpanded = !mapSectionExpanded;
    const content = document.getElementById('map-section-content');
    const icon = document.getElementById('map-section-icon');
    
    if (content && icon) {
        if (mapSectionExpanded) {
            content.style.display = 'block';
            icon.textContent = '▲';
            icon.style.transform = 'rotate(0deg)';
            // 지도 이벤트 리스너 다시 추가
            setTimeout(() => {
                attachMapEventListeners((regionName) => {
                    const color = getColorByRegion(regionName);
                    if (color) {
                        selectRegionColor(color);
                        toggleMapSection(); // 선택 후 자동으로 접기
                    }
                });
            }, 0);
        } else {
            content.style.display = 'none';
            icon.textContent = '▼';
            icon.style.transform = 'rotate(0deg)';
        }
    }
}

// 지역 색상 선택 함수 (지도에서 사용)
function selectRegionColor(color) {
    selectedColor = color;
    renderHomePage();
    
    // 색상 선택 결과 섹션으로 스크롤
    setTimeout(() => {
        const resultsSection = document.querySelector('.color-destination-results, .no-destinations');
        if (resultsSection) {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}
