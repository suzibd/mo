// Reservation Page

function renderReservationPage() {
    const app = document.getElementById('app');
    const reservations = storage.get('reservations') || [];
    const destinations = storage.get('destinations') || [];

    app.innerHTML = `
        <div class="reservation-page">
            <div class="container">
                <div class="reservation-header">
                    <h1>내 예약 관리</h1>
                    <button class="btn btn-primary" onclick="showReservationModal(null)">+ 새 예약하기</button>
                </div>

                ${reservations.length > 0 ? `
                    <div class="reservations-list">
                        ${reservations.map(reservation => {
                            const destination = destinations.find(d => d.id === reservation.destinationId);
                            return createReservationCard(reservation, destination);
                        }).join('')}
                    </div>
                ` : `
                    <div class="no-reservations">
                        <h2>아직 예약이 없습니다</h2>
                        <p>여행지를 예약하여 나만의 여행을 계획해보세요!</p>
                        <button class="btn btn-primary btn-large" onclick="showReservationModal(null)">첫 예약하기</button>
                    </div>
                `}
            </div>
        </div>
    `;
}

function createReservationCard(reservation, destination) {
    const statusColors = {
        'pending': '#FF9800',
        'confirmed': '#4CAF50',
        'cancelled': '#F44336',
        'completed': '#757575'
    };

    const statusNames = {
        'pending': '대기중',
        'confirmed': '확정',
        'cancelled': '취소됨',
        'completed': '완료'
    };

    const statusColor = statusColors[reservation.status] || '#757575';
    const statusName = statusNames[reservation.status] || reservation.status;

    return `
        <div class="reservation-card" data-id="${reservation.id}">
            <div class="reservation-content">
                <div class="reservation-info">
                    <h3 class="reservation-title">${destination ? escapeHtml(destination.name) : '알 수 없는 여행지'}</h3>
                    <div class="reservation-details">
                        <div class="detail-item">
                            <span class="detail-label">📅 체크인:</span>
                            <span class="detail-value">${formatDate(reservation.checkIn, 'YYYY.MM.DD')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">📅 체크아웃:</span>
                            <span class="detail-value">${formatDate(reservation.checkOut, 'YYYY.MM.DD')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">👥 인원:</span>
                            <span class="detail-value">${reservation.guests}명</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">💰 총 금액:</span>
                            <span class="detail-value">${formatCurrency(reservation.totalPrice)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">예약 일시:</span>
                            <span class="detail-value">${formatDate(reservation.createdAt, 'YYYY.MM.DD HH:mm')}</span>
                        </div>
                    </div>
                    ${reservation.notes ? `
                        <div class="reservation-notes">
                            <span class="detail-label">📝 메모:</span>
                            <span>${escapeHtml(reservation.notes)}</span>
                        </div>
                    ` : ''}
                </div>
                <div class="reservation-status">
                    <span class="status-badge" style="background-color: ${statusColor}20; color: ${statusColor};">
                        ${statusName}
                    </span>
                </div>
            </div>
            <div class="reservation-actions">
                ${reservation.status === 'pending' || reservation.status === 'confirmed' ? `
                    <button class="btn btn-error" onclick="cancelReservation('${reservation.id}')">예약 취소</button>
                ` : ''}
                ${reservation.status === 'confirmed' ? `
                    <button class="btn btn-primary" onclick="viewReservationDetail('${reservation.id}')">상세 보기</button>
                ` : ''}
                ${reservation.status === 'completed' ? `
                    <button class="btn btn-secondary" onclick="viewReservationDetail('${reservation.id}')">내역 보기</button>
                ` : ''}
            </div>
        </div>
    `;
}

// 예약 모달 표시
function showReservationModal(destinationId) {
    const destinations = storage.get('destinations') || [];
    const destination = destinationId ? destinations.find(d => d.id === destinationId) : null;

    let destinationSelect = '';
    if (destinationId && destination) {
        destinationSelect = `<input type="hidden" id="reservation-destination" value="${destination.id}">
            <div class="form-group">
                <label>여행지</label>
                <div class="selected-destination">
                    <strong>${escapeHtml(destination.name)}</strong>
                    <span style="color: var(--color-text-secondary);">${escapeHtml(destination.country)}</span>
                </div>
            </div>`;
    } else {
        destinationSelect = `
            <div class="form-group">
                <label for="reservation-destination">여행지 선택</label>
                <select id="reservation-destination" class="form-input" required>
                    <option value="">여행지를 선택하세요</option>
                    ${destinations.map(d => `
                        <option value="${d.id}">${escapeHtml(d.name)} - ${escapeHtml(d.country)}</option>
                    `).join('')}
                </select>
            </div>`;
    }

    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const reservationContent = `
        <form id="reservation-form" onsubmit="handleReservationSubmit(event); return false;">
            ${destinationSelect}
            <div class="form-group">
                <label for="reservation-checkin">체크인</label>
                <input type="date" id="reservation-checkin" class="form-input" required min="${today}">
            </div>
            <div class="form-group">
                <label for="reservation-checkout">체크아웃</label>
                <input type="date" id="reservation-checkout" class="form-input" required min="${today}">
            </div>
            <div class="form-group">
                <label for="reservation-guests">인원 수</label>
                <input type="number" id="reservation-guests" class="form-input" min="1" max="10" value="2" required>
            </div>
            <div class="form-group">
                <label for="reservation-price">1박 가격</label>
                <input type="number" id="reservation-price" class="form-input" min="0" value="${destination ? destination.estimatedBudget.min / 3 : 100000}" required>
            </div>
            <div class="form-group">
                <label for="reservation-notes">메모 (선택사항)</label>
                <textarea id="reservation-notes" class="form-input" rows="3" placeholder="추가 요청사항이나 메모를 입력하세요"></textarea>
            </div>
            <div class="form-summary">
                <div class="summary-item">
                    <span>예상 총 금액:</span>
                    <strong id="total-price">0원</strong>
                </div>
            </div>
            <div class="modal-footer-actions">
                <button type="button" class="btn btn-secondary" onclick="modal.close()">취소</button>
                <button type="submit" class="btn btn-primary">예약하기</button>
            </div>
        </form>
    `;

    modal.show('여행지 예약하기', reservationContent);

    // 날짜 변경 시 총 금액 계산
    const checkInInput = document.getElementById('reservation-checkin');
    const checkOutInput = document.getElementById('reservation-checkout');
    const guestsInput = document.getElementById('reservation-guests');
    const priceInput = document.getElementById('reservation-price');
    const totalPriceDisplay = document.getElementById('total-price');

    function calculateTotal() {
        if (checkInInput.value && checkOutInput.value && priceInput.value) {
            const checkIn = new Date(checkInInput.value);
            const checkOut = new Date(checkOutInput.value);
            const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
            const guests = parseInt(guestsInput.value) || 1;
            const pricePerNight = parseInt(priceInput.value) || 0;
            const total = nights * pricePerNight * guests;
            totalPriceDisplay.textContent = formatCurrency(total);
        } else {
            totalPriceDisplay.textContent = '0원';
        }
    }

    checkInInput.addEventListener('change', calculateTotal);
    checkOutInput.addEventListener('change', calculateTotal);
    guestsInput.addEventListener('input', calculateTotal);
    priceInput.addEventListener('input', calculateTotal);

    // 체크인 날짜가 체크아웃보다 이후가 되지 않도록
    checkInInput.addEventListener('change', function() {
        if (checkOutInput.value && this.value > checkOutInput.value) {
            checkOutInput.value = this.value;
            calculateTotal();
        }
        checkOutInput.min = this.value;
    });
}

// 예약 제출 처리
function handleReservationSubmit(event) {
    event.preventDefault();

    const destinationId = document.getElementById('reservation-destination').value;
    const checkIn = document.getElementById('reservation-checkin').value;
    const checkOut = document.getElementById('reservation-checkout').value;
    const guests = parseInt(document.getElementById('reservation-guests').value);
    const pricePerNight = parseInt(document.getElementById('reservation-price').value);
    const notes = document.getElementById('reservation-notes').value.trim();

    if (!destinationId || !checkIn || !checkOut) {
        toast.error('모든 필수 항목을 입력해주세요.');
        return;
    }

    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const nights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));

    if (nights <= 0) {
        toast.error('체크아웃 날짜는 체크인 날짜보다 이후여야 합니다.');
        return;
    }

    const totalPrice = nights * pricePerNight * guests;

    const reservation = {
        id: 'reservation_' + Date.now(),
        destinationId: destinationId,
        checkIn: checkIn,
        checkOut: checkOut,
        guests: guests,
        nights: nights,
        pricePerNight: pricePerNight,
        totalPrice: totalPrice,
        notes: notes,
        status: 'pending',
        createdAt: new Date().toISOString()
    };

    // 예약 저장
    const reservations = storage.get('reservations') || [];
    reservations.push(reservation);
    storage.set('reservations', reservations);

    modal.close();
    toast.success('예약이 완료되었습니다!');
    
    // 예약 페이지가 열려있으면 새로고침
    if (window.location.pathname === '/reservations') {
        renderReservationPage();
    } else {
        router.navigate('/reservations');
    }
}

// 예약 취소
function cancelReservation(reservationId) {
    modal.confirm(
        '예약 취소',
        '정말로 이 예약을 취소하시겠습니까?',
        () => {
            const reservations = storage.get('reservations') || [];
            const index = reservations.findIndex(r => r.id === reservationId);
            if (index !== -1) {
                reservations[index].status = 'cancelled';
                storage.set('reservations', reservations);
                toast.success('예약이 취소되었습니다.');
                renderReservationPage();
            }
        }
    );
}

// 예약 상세 보기
function viewReservationDetail(reservationId) {
    const reservations = storage.get('reservations') || [];
    const reservation = reservations.find(r => r.id === reservationId);
    const destinations = storage.get('destinations') || [];
    const destination = destinations.find(d => d.id === reservation.destinationId);

    if (!reservation) {
        toast.error('예약 정보를 찾을 수 없습니다.');
        return;
    }

    const detailContent = `
        <div class="reservation-detail">
            <div class="detail-section">
                <h3>예약 정보</h3>
                <div class="detail-item">
                    <span class="detail-label">여행지:</span>
                    <span class="detail-value">${destination ? escapeHtml(destination.name) : '알 수 없음'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">체크인:</span>
                    <span class="detail-value">${formatDate(reservation.checkIn, 'YYYY.MM.DD')}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">체크아웃:</span>
                    <span class="detail-value">${formatDate(reservation.checkOut, 'YYYY.MM.DD')}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">박 수:</span>
                    <span class="detail-value">${reservation.nights}박</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">인원:</span>
                    <span class="detail-value">${reservation.guests}명</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">1박 가격:</span>
                    <span class="detail-value">${formatCurrency(reservation.pricePerNight)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">총 금액:</span>
                    <span class="detail-value"><strong>${formatCurrency(reservation.totalPrice)}</strong></span>
                </div>
                ${reservation.notes ? `
                    <div class="detail-item">
                        <span class="detail-label">메모:</span>
                        <span class="detail-value">${escapeHtml(reservation.notes)}</span>
                    </div>
                ` : ''}
            </div>
        </div>
    `;

    modal.show('예약 상세 정보', detailContent);
}
