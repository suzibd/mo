// Destination Detail Page

function renderDestinationPage(params) {
    const app = document.getElementById('app');
    const destinationId = params.id;
    const destination = storage.findById('destinations', destinationId);

    if (!destination) {
        app.innerHTML = `
            <div class="container" style="padding: 4rem 0; text-align: center;">
                <h1>여행지를 찾을 수 없습니다</h1>
                <p style="margin: var(--spacing-lg) 0;">요청하신 여행지가 존재하지 않습니다.</p>
                <a href="/search" data-link class="btn btn-primary">여행지 검색하기</a>
            </div>
        `;
        return;
    }

    // 이 여행지의 후기 가져오기
    const allReviews = storage.get('reviews') || [];
    const destinationReviews = allReviews.filter(r => r.destinationId === destinationId);

    // 관련 여행지 (같은 카테고리)
    const allDestinations = storage.get('destinations') || [];
    const relatedDestinations = allDestinations
        .filter(d => d.id !== destinationId && d.category.some(cat => destination.category.includes(cat)))
        .slice(0, 3);

    app.innerHTML = `
        <div class="destination-page">
            <!-- 헤더 -->
            <div class="destination-header">
                <div class="container">
                    <button class="btn btn-secondary" onclick="history.back()">← 뒤로 가기</button>
                </div>
            </div>

            <!-- 메인 이미지 -->
            <div class="destination-hero">
                <img src="${destination.imageUrl}" alt="${escapeHtml(destination.name)}">
            </div>

            <!-- 정보 섹션 -->
            <div class="container">
                <div class="destination-info">
                    <!-- 기본 정보 -->
                    <div class="destination-main">
                        <h1>${escapeHtml(destination.name)}</h1>
                        <p class="destination-country">${escapeHtml(destination.country)}</p>

                        <div class="rating" style="margin: var(--spacing-md) 0;">
                            <span class="stars">${renderStars(destination.rating)}</span>
                            <span style="font-size: var(--font-size-lg); margin-left: var(--spacing-xs); font-weight: var(--font-weight-bold);">
                                ${destination.rating}
                            </span>
                            <span style="color: var(--color-text-secondary); margin-left: var(--spacing-xs);">
                                (${destination.reviewCount}개의 후기)
                            </span>
                        </div>

                        <div class="tags" style="margin: var(--spacing-md) 0;">
                            ${destination.category.map(cat => `
                                <span class="tag" style="background-color: ${getCategoryColor(cat)}20; color: ${getCategoryColor(cat)}; font-size: var(--font-size-base); padding: var(--spacing-sm) var(--spacing-md);">
                                    ${cat}
                                </span>
                            `).join('')}
                        </div>

                        <button class="btn btn-primary btn-large" onclick="addToPlanner('${destination.id}')">
                            + 여행 계획에 추가
                        </button>
                    </div>

                    <!-- 상세 정보 -->
                    <div class="destination-details">
                        <div class="detail-section">
                            <h2>소개</h2>
                            <p>${escapeHtml(destination.description)}</p>
                        </div>

                        <div class="detail-section">
                            <h2>하이라이트</h2>
                            <ul class="highlights-list">
                                ${destination.highlights.map(h => `<li>${escapeHtml(h)}</li>`).join('')}
                            </ul>
                        </div>

                        <div class="detail-section">
                            <h2>추천 계절</h2>
                            <div class="seasons">
                                ${destination.bestSeason.map(s => `
                                    <span class="season-badge">${s}</span>
                                `).join('')}
                            </div>
                        </div>

                        <div class="detail-section">
                            <h2>예상 예산</h2>
                            <p class="budget-info">
                                ${formatCurrency(destination.estimatedBudget.min)} ~
                                ${formatCurrency(destination.estimatedBudget.max)}
                            </p>
                            <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin-top: var(--spacing-xs);">
                                1인당 평균 비용 (교통, 숙박, 식사 포함)
                            </p>
                        </div>
                    </div>
                </div>

                <!-- 후기 섹션 -->
                <div class="destination-reviews">
                    <div class="section-header">
                        <h2>여행 후기 (${destinationReviews.length})</h2>
                        <button class="btn btn-primary" onclick="writeReview('${destination.id}')">후기 작성하기</button>
                    </div>

                    ${destinationReviews.length > 0 ? `
                        <div class="reviews-list">
                            ${destinationReviews.map(review => `
                                <div class="review-item">
                                    <div class="rating">
                                        <span class="stars">${renderStars(review.rating)}</span>
                                    </div>
                                    <h3>${escapeHtml(review.title)}</h3>
                                    <p>${escapeHtml(review.content)}</p>
                                    <div class="review-meta">
                                        <span>${formatDate(review.visitDate, 'YYYY.MM.DD')}</span>
                                        <span>👍 ${review.helpful}</span>
                                    </div>
                                    <div class="tags">
                                        ${review.tags.map(tag => `<span class="tag">#${tag}</span>`).join('')}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    ` : `
                        <p style="text-align: center; color: var(--color-text-secondary); padding: var(--spacing-xl);">
                            아직 후기가 없습니다. 첫 번째 후기를 작성해보세요!
                        </p>
                    `}
                </div>

                <!-- 추천 여행지 -->
                ${relatedDestinations.length > 0 ? `
                    <div class="related-destinations">
                        <h2>추천 여행지</h2>
                        <div class="grid grid-3">
                            ${relatedDestinations.map(dest => createDestinationCard(dest)).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

function addToPlanner(destinationId) {
    toast.info('여행 계획 기능은 계획 페이지에서 이용하실 수 있습니다');
    setTimeout(() => {
        router.navigate('/planner');
    }, 1500);
}

function writeReview(destinationId) {
    router.navigate(`/reviews?destination=${destinationId}`);
}
