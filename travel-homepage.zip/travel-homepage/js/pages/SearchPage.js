// Search Page

let searchState = {
    query: '',
    category: '',
    season: '',
    budgetLevel: '',
    sortBy: 'popular',
    color: ''
};

function renderSearchPage(params = {}) {
    const app = document.getElementById('app');

    // URL 쿼리 파라미터에서 검색어 가져오기
    if (params.q) {
        searchState.query = decodeURIComponent(params.q);
    }

    // URL 쿼리 파라미터에서 색상 가져오기
    if (params.color) {
        searchState.color = decodeURIComponent(params.color);
    } else {
        // 파라미터에 없으면 쿼리 파라미터에서 가져오기
        const queryParams = getQueryParams();
        if (queryParams.color) {
            searchState.color = queryParams.color;
        }
    }

    const allDestinations = storage.get('destinations') || [];
    const filteredDestinations = filterDestinations(allDestinations);

    // 색상이 설정되어 있으면 헤더에 표시
    let colorHeader = '';
    if (searchState.color) {
        const colorName = getColorName(searchState.color);
        const regionsForColor = getRegionsByColor(searchState.color);
        colorHeader = `
            <div class="color-filter-header" style="background: linear-gradient(135deg, ${searchState.color}15 0%, ${searchState.color}05 100%); padding: var(--spacing-md); border-radius: var(--border-radius); margin-bottom: var(--spacing-lg);">
                <div style="display: flex; align-items: center; gap: var(--spacing-sm);">
                    <span class="color-badge" style="background-color: ${searchState.color};"></span>
                    <h2 style="margin: 0; font-size: var(--font-size-xl);">${colorName}색 여행지</h2>
                </div>
                ${regionsForColor.length > 0 ? `<p style="margin: var(--spacing-xs) 0 0 0; color: var(--color-text-secondary);">${regionsForColor.join(', ')} 지역</p>` : ''}
            </div>
        `;
    }

    app.innerHTML = `
        <div class="search-page">
            <div class="container">
                <!-- 검색 헤더 -->
                <div class="search-header">
                    <h1>여행지 검색</h1>
                    <div class="search-bar">
                        <input type="text"
                               id="search-input"
                               class="search-input"
                               placeholder="여행지 이름으로 검색..."
                               value="${escapeHtml(searchState.query)}"${escapeHtml(searchState.query)}">
                        <button class="btn btn-primary" onclick="performSearch()">검색</button>
                    </div>
                </div>

                <!-- 필터 및 정렬 -->
                <div class="search-filters">
                    <div class="filter-group">
                        <label>카테고리:</label>
                        <select id="filter-category" onchange="updateFilters()">
                            <option value="">전체</option>
                            <option value="자연">자연</option>
                            <option value="도시">도시</option>
                            <option value="문화">문화</option>
                            <option value="해변">해변</option>
                            <option value="힐링">힐링</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label>계절:</label>
                        <select id="filter-season" onchange="updateFilters()">
                            <option value="">전체</option>
                            <option value="봄">봄</option>
                            <option value="여름">여름</option>
                            <option value="가을">가을</option>
                            <option value="겨울">겨울</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label>예산:</label>
                        <select id="filter-budget" onchange="updateFilters()">
                            <option value="">전체</option>
                            <option value="low">낮음 (30만원 이하)</option>
                            <option value="medium">중간 (30-70만원)</option>
                            <option value="high">높음 (70만원 이상)</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label>정렬:</label>
                        <select id="sort-by" onchange="updateFilters()">
                            <option value="popular">인기순</option>
                            <option value="rating">평점순</option>
                            <option value="name">이름순</option>
                            <option value="budget-low">가격 낮은순</option>
                            <option value="budget-high">가격 높은순</option>
                        </select>
                    </div>
                </div>

                <!-- 검색 결과 -->
                <div class="search-results">
                    ${colorHeader}
                    <div class="results-header">
                        <h2>검색 결과 (${filteredDestinations.length}개)</h2>
                        <button class="btn btn-secondary" onclick="resetFilters()">필터 초기화</button>
                    </div>

                    ${filteredDestinations.length > 0 ? `
                        <div class="grid grid-4">
                            ${filteredDestinations.map(dest => createDestinationCard(dest)).join('')}
                        </div>
                    ` : `
                        <div class="no-results">
                            <p>검색 결과가 없습니다.</p>
                            <p>다른 검색어나 필터를 시도해보세요.</p>
                        </div>
                    `}
                </div>
            </div>
        </div>
    `;

    // 필터 값 설정
    document.getElementById('filter-category').value = searchState.category;
    document.getElementById('filter-season').value = searchState.season;
    document.getElementById('filter-budget').value = searchState.budgetLevel;
    document.getElementById('sort-by').value = searchState.sortBy;

    // 검색 입력 엔터 키 처리
    document.getElementById('search-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
}

function performSearch() {
    const query = document.getElementById('search-input').value.trim();
    searchState.query = query;
    renderSearchPage();
}

function updateFilters() {
    searchState.category = document.getElementById('filter-category').value;
    searchState.season = document.getElementById('filter-season').value;
    searchState.budgetLevel = document.getElementById('filter-budget').value;
    searchState.sortBy = document.getElementById('sort-by').value;
    renderSearchPage();
}

function resetFilters() {
    searchState = {
        query: '',
        category: '',
        season: '',
        budgetLevel: '',
        sortBy: 'popular',
        color: ''
    };
    router.navigate('/search');
}

function filterDestinations(destinations) {
    let filtered = [...destinations];

    // 색상 필터 (가장 먼저 적용)
    if (searchState.color) {
        const regionsForColor = getRegionsByColor(searchState.color);
        if (regionsForColor.length > 0) {
            filtered = filterDestinationsByRegions(filtered, regionsForColor);
        } else {
            // 해당 색상에 지역이 없으면 결과 없음
            filtered = [];
        }
    }

    // 텍스트 검색
    if (searchState.query) {
        const queryLower = searchState.query.toLowerCase();
        filtered = filtered.filter(dest => {
            return (
                dest.name.toLowerCase().includes(queryLower) ||
                dest.description.toLowerCase().includes(queryLower) ||
                dest.country.toLowerCase().includes(queryLower) ||
                dest.category.some(cat => cat.toLowerCase().includes(queryLower)) ||
                dest.highlights.some(highlight => highlight.toLowerCase().includes(queryLower))
            );
        });
    }

    // 카테고리 필터
    if (searchState.category) {
        filtered = filtered.filter(dest => dest.category.includes(searchState.category));
    }

    // 계절 필터
    if (searchState.season) {
        filtered = filtered.filter(dest => dest.bestSeason.includes(searchState.season));
    }

    // 예산 필터
    if (searchState.budgetLevel) {
        filtered = filtered.filter(dest => {
            const avgBudget = (dest.estimatedBudget.min + dest.estimatedBudget.max) / 2;
            const level = getBudgetLevel(avgBudget);
            return level === searchState.budgetLevel;
        });
    }

    // 정렬
    switch (searchState.sortBy) {
        case 'rating':
            filtered.sort((a, b) => b.rating - a.rating);
            break;
        case 'name':
            filtered.sort((a, b) => a.name.localeCompare(b.name, 'ko'));
            break;
        case 'budget-low':
            filtered.sort((a, b) => a.estimatedBudget.min - b.estimatedBudget.min);
            break;
        case 'budget-high':
            filtered.sort((a, b) => b.estimatedBudget.max - a.estimatedBudget.max);
            break;
        case 'popular':
        default:
            filtered.sort((a, b) => b.reviewCount - a.reviewCount);
            break;
    }

    return filtered;
}
