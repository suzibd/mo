// Planner Page

function renderPlannerPage() {
    const app = document.getElementById('app');
    const plans = storage.get('travelPlans') || [];

    app.innerHTML = `
        <div class="planner-page">
            <div class="container">
                <div class="planner-header">
                    <h1>내 여행 계획</h1>
                    <button class="btn btn-primary" onclick="showCreatePlanModal()">+ 새 계획 만들기</button>
                </div>

                ${plans.length > 0 ? `
                    <div class="plans-grid">
                        ${plans.map(plan => createPlanCard(plan)).join('')}
                    </div>
                ` : `
                    <div class="no-plans">
                        <h2>아직 여행 계획이 없습니다</h2>
                        <p>새로운 여행을 계획해보세요!</p>
                        <button class="btn btn-primary btn-large" onclick="showCreatePlanModal()">첫 계획 만들기</button>
                    </div>
                `}
            </div>
        </div>
    `;
}

function showCreatePlanModal() {
    const destinations = storage.get('destinations') || [];

    const content = `
        <form id="create-plan-form" onsubmit="event.preventDefault(); createPlan();">
            <div class="form-group">
                <label class="form-label">여행 제목</label>
                <input type="text" id="plan-title" class="form-input" required placeholder="예: 제주도 힐링 여행">
            </div>

            <div class="form-group">
                <label class="form-label">여행지</label>
                <select id="plan-destination" class="form-select" required>
                    <option value="">선택하세요</option>
                    ${destinations.map(dest => `
                        <option value="${dest.id}">${escapeHtml(dest.name)}</option>
                    `).join('')}
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">시작 날짜</label>
                <input type="date" id="plan-start-date" class="form-input" required>
            </div>

            <div class="form-group">
                <label class="form-label">종료 날짜</label>
                <input type="date" id="plan-end-date" class="form-input" required>
            </div>

            <div class="form-group">
                <label class="form-label">예산 (원)</label>
                <input type="number" id="plan-budget" class="form-input" required min="0" step="10000" placeholder="600000">
            </div>

            <div class="form-group">
                <label class="form-label">인원</label>
                <input type="number" id="plan-participants" class="form-input" required min="1" value="1">
            </div>

            <div class="form-group">
                <label class="form-label">메모 (선택)</label>
                <textarea id="plan-notes" class="form-textarea" placeholder="여행 관련 메모를 입력하세요"></textarea>
            </div>
        </form>
    `;

    modal.show('새 여행 계획 만들기', content, [
        {
            label: '취소',
            className: 'btn-secondary',
            onClick: 'modal.close()'
        },
        {
            label: '생성',
            className: 'btn-primary',
            onClick: 'document.getElementById(\'create-plan-form\').requestSubmit()'
        }
    ]);
}

function createPlan() {
    const title = document.getElementById('plan-title').value;
    const destinationId = document.getElementById('plan-destination').value;
    const startDate = document.getElementById('plan-start-date').value;
    const endDate = document.getElementById('plan-end-date').value;
    const budget = parseInt(document.getElementById('plan-budget').value);
    const participants = parseInt(document.getElementById('plan-participants').value);
    const notes = document.getElementById('plan-notes').value;

    // 날짜 유효성 검사
    if (new Date(startDate) > new Date(endDate)) {
        toast.error('종료 날짜는 시작 날짜보다 늦어야 합니다');
        return;
    }

    const plan = {
        id: storage.generateId('plan'),
        title,
        destinationId,
        startDate,
        endDate,
        budget,
        participants,
        notes,
        status: 'planned',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        itinerary: []
    };

    storage.add('travelPlans', plan);
    modal.close();
    toast.success('여행 계획이 생성되었습니다');
    renderPlannerPage();
}

function viewPlan(planId) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan) {
        toast.error('계획을 찾을 수 없습니다');
        return;
    }

    const destination = storage.findById('destinations', plan.destinationId);
    const days = daysBetween(plan.startDate, plan.endDate) + 1;

    const content = `
        <div class="plan-detail">
            <div class="plan-info">
                <p><strong>여행지:</strong> ${destination ? escapeHtml(destination.name) : '알 수 없음'}</p>
                <p><strong>기간:</strong> ${formatDate(plan.startDate, 'YYYY.MM.DD')} ~ ${formatDate(plan.endDate, 'YYYY.MM.DD')} (${days}일)</p>
                <p><strong>예산:</strong> ${formatCurrency(plan.budget)}</p>
                <p><strong>인원:</strong> ${plan.participants}명</p>
                <p><strong>상태:</strong> <span style="color: ${getStatusColor(plan.status)};">${getStatusKorean(plan.status)}</span></p>
                ${plan.notes ? `<p><strong>메모:</strong> ${escapeHtml(plan.notes)}</p>` : ''}
            </div>

            ${plan.itinerary && plan.itinerary.length > 0 ? `
                <div class="plan-itinerary">
                    <h3>일정</h3>
                    ${plan.itinerary.map(day => `
                        <div class="day-section">
                            <h4>Day ${day.day} - ${formatDate(day.date, 'YYYY.MM.DD')}</h4>
                            ${day.activities.map(activity => `
                                <div class="activity-item">
                                    <span class="activity-time">${activity.time}</span>
                                    <span class="activity-title">${escapeHtml(activity.title)}</span>
                                    ${activity.cost > 0 ? `<span class="activity-cost">${formatCurrency(activity.cost)}</span>` : ''}
                                </div>
                            `).join('')}
                        </div>
                    `).join('')}
                </div>
            ` : '<p style="color: var(--color-text-secondary);">아직 일정이 없습니다.</p>'}
        </div>
    `;

    modal.show(escapeHtml(plan.title), content, [
        {
            label: '닫기',
            className: 'btn-secondary',
            onClick: 'modal.close()'
        }
    ]);
}

function editPlan(planId) {
    toast.info('편집 기능은 향후 추가될 예정입니다');
}

function deletePlan(planId) {
    const plan = storage.findById('travelPlans', planId);
    if (!plan) {
        toast.error('계획을 찾을 수 없습니다');
        return;
    }

    if (confirm(`"${plan.title}" 계획을 삭제하시겠습니까?`)) {
        storage.delete('travelPlans', planId);
        toast.success('계획이 삭제되었습니다');
        renderPlannerPage();
    }
}
