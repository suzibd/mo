// 지역별 색상 매핑 데이터 (각 지역당 하나의 색상)
const REGION_COLOR_MAP = {
    '서울': '#FF0000',      // 빨강 - 활기찬 도시
    '인천': '#03A9F4',      // 하늘색 - 국제 항구
    '부산': '#FF5722',      // 주황빨강 - 해안 도시
    '제주': '#4CAF50',      // 초록 - 자연 힐링
    '강릉': '#00BCD4',      // 청록 - 시원한 해안
    '전주': '#9C27B0',      // 보라 - 전통 문화
    '경주': '#FFC107',      // 노랑 - 역사 문화
    '여수': '#2196F3'       // 파랑 - 아름다운 해안
};

// 색상별 지역 매핑 (역방향 검색용)
const COLOR_REGION_MAP = {};
Object.keys(REGION_COLOR_MAP).forEach(region => {
    const color = REGION_COLOR_MAP[region];
    if (!COLOR_REGION_MAP[color]) {
        COLOR_REGION_MAP[color] = [];
    }
    COLOR_REGION_MAP[color].push(region);
});

// 색상 이름 매핑
const COLOR_NAMES = {
    '#FF0000': '빨강',
    '#FF5722': '주황빨강',
    '#FFC107': '노랑',
    '#4CAF50': '초록',
    '#2196F3': '파랑',
    '#03A9F4': '하늘색',
    '#9C27B0': '보라',
    '#00BCD4': '청록'
};

// 사용 가능한 색상 배열
const AVAILABLE_COLORS = Object.keys(COLOR_REGION_MAP);

// 지역명으로 색상 가져오기
function getColorByRegion(regionName) {
    return REGION_COLOR_MAP[regionName] || null;
}
