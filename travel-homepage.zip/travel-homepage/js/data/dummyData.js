// Dummy Data for Travel Homepage

const DUMMY_DESTINATIONS = [
    {
        id: "dest_001",
        name: "제주도",
        country: "대한민국",
        category: ["자연", "힐링", "액티비티"],
        description: "대한민국 최남단의 화산섬으로, 아름다운 자연경관과 독특한 문화를 자랑합니다. 한라산, 성산일출봉, 만장굴 등 유네스코 세계자연유산이 있습니다.",
        imageUrl: "https://via.placeholder.com/400x300/4CAF50/FFFFFF?text=제주도",
        rating: 4.7,
        reviewCount: 342,
        highlights: ["한라산 등반", "해변과 올레길", "돌하르방", "흑돼지 고기"],
        bestSeason: ["봄", "가을"],
        estimatedBudget: { min: 300000, max: 800000, currency: "KRW" }
    },
    {
        id: "dest_002",
        name: "부산",
        country: "대한민국",
        category: ["도시", "해변", "문화"],
        description: "대한민국 제2의 도시이자 최대 항구도시. 해운대 해수욕장, 광안리, 자갈치 시장 등이 유명합니다.",
        imageUrl: "https://via.placeholder.com/400x300/2196F3/FFFFFF?text=부산",
        rating: 4.5,
        reviewCount: 289,
        highlights: ["해운대 해수욕장", "광안대교 야경", "감천문화마을", "자갈치 시장"],
        bestSeason: ["여름", "가을"],
        estimatedBudget: { min: 250000, max: 600000, currency: "KRW" }
    },
    {
        id: "dest_003",
        name: "서울",
        country: "대한민국",
        category: ["도시", "문화", "쇼핑"],
        description: "대한민국의 수도이자 정치, 경제, 문화의 중심지. 전통과 현대가 공존하는 역동적인 도시입니다.",
        imageUrl: "https://via.placeholder.com/400x300/FF9800/FFFFFF?text=서울",
        rating: 4.6,
        reviewCount: 512,
        highlights: ["경복궁", "명동 쇼핑", "남산타워", "한강 공원"],
        bestSeason: ["봄", "가을"],
        estimatedBudget: { min: 300000, max: 1000000, currency: "KRW" }
    },
    {
        id: "dest_004",
        name: "강릉",
        country: "대한민국",
        category: ["자연", "해변", "힐링"],
        description: "동해안의 대표 관광도시. 아름다운 해변과 커피거리로 유명합니다.",
        imageUrl: "https://via.placeholder.com/400x300/00BCD4/FFFFFF?text=강릉",
        rating: 4.4,
        reviewCount: 178,
        highlights: ["경포대 해변", "안목 커피거리", "정동진", "오죽헌"],
        bestSeason: ["여름", "가을"],
        estimatedBudget: { min: 200000, max: 500000, currency: "KRW" }
    },
    {
        id: "dest_005",
        name: "전주",
        country: "대한민국",
        category: ["문화", "음식", "전통"],
        description: "전통 한옥마을과 비빔밥으로 유명한 문화의 도시입니다.",
        imageUrl: "https://via.placeholder.com/400x300/9C27B0/FFFFFF?text=전주",
        rating: 4.5,
        reviewCount: 234,
        highlights: ["한옥마을", "비빔밥", "전동성당", "남부시장"],
        bestSeason: ["봄", "가을"],
        estimatedBudget: { min: 150000, max: 400000, currency: "KRW" }
    },
    {
        id: "dest_006",
        name: "경주",
        country: "대한민국",
        category: ["문화", "역사", "전통"],
        description: "신라 천년의 고도. 불국사, 석굴암 등 유네스코 세계문화유산이 있습니다.",
        imageUrl: "https://via.placeholder.com/400x300/795548/FFFFFF?text=경주",
        rating: 4.6,
        reviewCount: 298,
        highlights: ["불국사", "석굴암", "대릉원", "안압지"],
        bestSeason: ["봄", "가을"],
        estimatedBudget: { min: 200000, max: 500000, currency: "KRW" }
    },
    {
        id: "dest_007",
        name: "속초",
        country: "대한민국",
        category: ["자연", "해변", "액티비티"],
        description: "설악산과 동해바다를 함께 즐길 수 있는 관광도시입니다.",
        imageUrl: "https://via.placeholder.com/400x300/FF5722/FFFFFF?text=속초",
        rating: 4.3,
        reviewCount: 156,
        highlights: ["설악산", "속초 해수욕장", "아바이마을", "영금정"],
        bestSeason: ["여름", "가을"],
        estimatedBudget: { min: 250000, max: 600000, currency: "KRW" }
    },
    {
        id: "dest_008",
        name: "여수",
        country: "대한민국",
        category: ["자연", "해변", "야경"],
        description: "아름다운 밤바다 야경과 해산물이 유명한 항구도시입니다.",
        imageUrl: "https://via.placeholder.com/400x300/3F51B5/FFFFFF?text=여수",
        rating: 4.5,
        reviewCount: 201,
        highlights: ["여수 밤바다", "오동도", "향일암", "해산물 요리"],
        bestSeason: ["봄", "여름"],
        estimatedBudget: { min: 250000, max: 600000, currency: "KRW" }
    }
];

const DUMMY_PLANS = [
    {
        id: "plan_001",
        title: "제주도 힐링 여행",
        destinationId: "dest_001",
        startDate: "2026-03-15",
        endDate: "2026-03-18",
        createdAt: "2026-01-05T10:00:00Z",
        updatedAt: "2026-01-05T10:00:00Z",
        budget: 600000,
        participants: 2,
        status: "planned",
        itinerary: [
            {
                day: 1,
                date: "2026-03-15",
                activities: [
                    { id: "act_001", time: "09:00", title: "제주공항 도착", location: "제주국제공항", duration: 60, cost: 0, notes: "렌트카 픽업" },
                    { id: "act_002", time: "12:00", title: "점심 식사", location: "돈사돈", duration: 90, cost: 40000, notes: "흑돼지 맛집" },
                    { id: "act_003", time: "14:00", title: "성산일출봉 등반", location: "성산일출봉", duration: 120, cost: 5000, notes: "유네스코 세계자연유산" }
                ]
            },
            {
                day: 2,
                date: "2026-03-16",
                activities: [
                    { id: "act_004", time: "08:00", title: "한라산 등반", location: "한라산", duration: 480, cost: 0, notes: "성판악 코스" }
                ]
            }
        ],
        notes: "가족 여행, 렌트카 필수"
    },
    {
        id: "plan_002",
        title: "부산 주말여행",
        destinationId: "dest_002",
        startDate: "2026-02-20",
        endDate: "2026-02-22",
        createdAt: "2026-01-03T14:00:00Z",
        updatedAt: "2026-01-03T14:00:00Z",
        budget: 400000,
        participants: 2,
        status: "planned",
        itinerary: [
            {
                day: 1,
                date: "2026-02-20",
                activities: [
                    { id: "act_005", time: "10:00", title: "감천문화마을 탐방", location: "감천문화마을", duration: 180, cost: 0, notes: "사진 촬영" },
                    { id: "act_006", time: "18:00", title: "광안리 야경", location: "광안리 해수욕장", duration: 120, cost: 30000, notes: "저녁 식사" }
                ]
            }
        ],
        notes: "연인과 함께"
    }
];

const DUMMY_REVIEWS = [
    {
        id: "review_001",
        destinationId: "dest_001",
        planId: "plan_001",
        title: "제주도 완벽한 봄 여행!",
        content: "날씨도 좋고 경치도 너무 아름다웠습니다. 한라산 등반은 조금 힘들었지만 정상에서 본 경치는 잊을 수 없네요. 가족들과 함께한 소중한 시간이었습니다.",
        rating: 5,
        visitDate: "2026-03-15",
        createdAt: "2026-03-19T10:00:00Z",
        photos: [],
        tags: ["가족여행", "렌트카", "힐링", "자연"],
        helpful: 23
    },
    {
        id: "review_002",
        destinationId: "dest_002",
        planId: null,
        title: "부산 야경이 정말 멋져요",
        content: "광안대교 야경을 보러 갔는데 정말 환상적이었어요. 해운대 해수욕장도 깨끗하고 좋았습니다.",
        rating: 4,
        visitDate: "2026-01-10",
        createdAt: "2026-01-12T15:00:00Z",
        photos: [],
        tags: ["야경", "해변", "데이트"],
        helpful: 15
    },
    {
        id: "review_003",
        destinationId: "dest_003",
        planId: null,
        title: "서울은 언제 가도 즐거워요",
        content: "경복궁에서 한복 입고 사진 찍었는데 정말 예뻤어요. 명동에서 쇼핑도 하고 맛있는 것도 많이 먹었습니다.",
        rating: 5,
        visitDate: "2025-12-25",
        createdAt: "2025-12-27T09:00:00Z",
        photos: [],
        tags: ["문화", "쇼핑", "맛집"],
        helpful: 31
    },
    {
        id: "review_004",
        destinationId: "dest_004",
        planId: null,
        title: "강릉 커피 투어 최고!",
        content: "안목 커피거리에서 바다 보면서 마시는 커피가 정말 맛있었어요. 경포대 해변도 산책하기 좋았습니다.",
        rating: 4,
        visitDate: "2025-11-05",
        createdAt: "2025-11-07T11:00:00Z",
        photos: [],
        tags: ["커피", "해변", "힐링"],
        helpful: 18
    },
    {
        id: "review_005",
        destinationId: "dest_005",
        planId: null,
        title: "전주 한옥마을 강추!",
        content: "한옥마을이 정말 예쁘고 비빔밥도 맛있었어요. 전통문화를 느낄 수 있어서 좋았습니다.",
        rating: 5,
        visitDate: "2025-10-15",
        createdAt: "2025-10-17T13:00:00Z",
        photos: [],
        tags: ["전통", "한옥", "음식"],
        helpful: 27
    }
];

// 더미 데이터 로드 함수
function loadDummyData() {
    // 데이터가 비어있을 때만 로드
    const destinations = storage.get('destinations');

    if (!destinations || destinations.length === 0) {
        console.log('Loading dummy data...');

        // 여행지 데이터 로드
        storage.set('destinations', DUMMY_DESTINATIONS);

        // 여행 계획 로드
        storage.set('travelPlans', DUMMY_PLANS);

        // 후기 로드
        storage.set('reviews', DUMMY_REVIEWS);

        // 추천 데이터 로드
        storage.set('recommendations', {
            popular: ["dest_001", "dest_002", "dest_003"],
            seasonal: {
                spring: ["dest_001", "dest_005", "dest_006"],
                summer: ["dest_002", "dest_004", "dest_007"],
                fall: ["dest_003", "dest_005", "dest_006"],
                winter: ["dest_004", "dest_007"]
            },
            byBudget: {
                low: ["dest_005", "dest_004"],
                medium: ["dest_001", "dest_002", "dest_006"],
                high: ["dest_003"]
            }
        });

        console.log('Dummy data loaded successfully');
    }
}
