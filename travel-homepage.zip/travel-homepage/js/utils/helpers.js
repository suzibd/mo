// Helper Functions

// 날짜 포맷팅
function formatDate(dateString, format = 'YYYY-MM-DD') {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    switch (format) {
        case 'YYYY-MM-DD':
            return `${year}-${month}-${day}`;
        case 'YYYY.MM.DD':
            return `${year}.${month}.${day}`;
        case 'YYYY년 MM월 DD일':
            return `${year}년 ${month}월 ${day}일`;
        default:
            return `${year}-${month}-${day}`;
    }
}

// 상대 시간 (몇 분 전, 몇 시간 전 등)
function timeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const months = Math.floor(days / 30);
    const years = Math.floor(days / 365);

    if (years > 0) return `${years}년 전`;
    if (months > 0) return `${months}개월 전`;
    if (days > 0) return `${days}일 전`;
    if (hours > 0) return `${hours}시간 전`;
    if (minutes > 0) return `${minutes}분 전`;
    return '방금 전';
}

// 통화 포맷팅
function formatCurrency(amount, currency = 'KRW') {
    if (currency === 'KRW') {
        return `${amount.toLocaleString('ko-KR')}원`;
    }
    return amount.toLocaleString('ko-KR');
}

// 별점 렌더링
function renderStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    let stars = '';

    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            stars += '★';
        } else if (i === fullStars && hasHalfStar) {
            stars += '⯨';
        } else {
            stars += '☆';
        }
    }

    return stars;
}

// HTML 이스케이프 (XSS 방지)
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// 디바운스
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 스로틀
function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// 배열 섞기
function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// 날짜 차이 계산 (일 수)
function daysBetween(date1, date2) {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = Math.abs(d2 - d1);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

// 계절 가져오기
function getCurrentSeason() {
    const month = new Date().getMonth() + 1;
    if (month >= 3 && month <= 5) return 'spring';
    if (month >= 6 && month <= 8) return 'summer';
    if (month >= 9 && month <= 11) return 'fall';
    return 'winter';
}

// 계절 한글 변환
function getSeasonKorean(season) {
    const seasons = {
        'spring': '봄',
        'summer': '여름',
        'fall': '가을',
        'winter': '겨울'
    };
    return seasons[season] || season;
}

// 카테고리 색상 가져오기
function getCategoryColor(category) {
    const colors = {
        '자연': '#4CAF50',
        '도시': '#2196F3',
        '문화': '#9C27B0',
        '해변': '#00BCD4',
        '힐링': '#8BC34A',
        '액티비티': '#FF5722',
        '쇼핑': '#FF9800',
        '음식': '#FF5722',
        '전통': '#795548',
        '역사': '#607D8B',
        '야경': '#3F51B5'
    };
    return colors[category] || '#757575';
}

// 예산 레벨 가져오기
function getBudgetLevel(budget) {
    if (budget < 300000) return 'low';
    if (budget < 700000) return 'medium';
    return 'high';
}

// 예산 레벨 한글
function getBudgetLevelKorean(level) {
    const levels = {
        'low': '낮음',
        'medium': '중간',
        'high': '높음'
    };
    return levels[level] || level;
}

// 평점 색상 가져오기
function getRatingColor(rating) {
    if (rating >= 4.5) return '#4CAF50';
    if (rating >= 4.0) return '#8BC34A';
    if (rating >= 3.5) return '#FFC107';
    if (rating >= 3.0) return '#FF9800';
    return '#F44336';
}

// 상태 한글 변환
function getStatusKorean(status) {
    const statuses = {
        'planned': '계획중',
        'in-progress': '진행중',
        'completed': '완료'
    };
    return statuses[status] || status;
}

// 상태 색상 가져오기
function getStatusColor(status) {
    const colors = {
        'planned': '#2196F3',
        'in-progress': '#FF9800',
        'completed': '#4CAF50'
    };
    return colors[status] || '#757575';
}

// URL에서 쿼리 파라미터 가져오기
function getQueryParams() {
    const params = {};
    const queryString = window.location.search.slice(1);
    const pairs = queryString.split('&');

    pairs.forEach(pair => {
        const [key, value] = pair.split('=');
        if (key) {
            params[decodeURIComponent(key)] = decodeURIComponent(value || '');
        }
    });

    return params;
}

// 쿼리 파라미터를 URL에 추가
function buildQueryString(params) {
    const keys = Object.keys(params);
    if (keys.length === 0) return '';

    const pairs = keys.map(key => {
        const value = params[key];
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
    });

    return '?' + pairs.join('&');
}

// 이미지 지연 로딩 설정
function setupLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    observer.unobserve(img);
                }
            });
        });

        document.querySelectorAll('img.lazy').forEach(img => {
            imageObserver.observe(img);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        document.querySelectorAll('img.lazy').forEach(img => {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
        });
    }
}

// 랜덤 색상 가져오기
function getRandomColor() {
    if (typeof AVAILABLE_COLORS === 'undefined' || AVAILABLE_COLORS.length === 0) {
        return '#2196F3'; // 기본 파랑색
    }
    
    // 랜덤으로 색상 선택
    const colorIndex = Math.floor(Math.random() * AVAILABLE_COLORS.length);
    return AVAILABLE_COLORS[colorIndex];
}

// 색상 이름 가져오기
function getColorName(colorCode) {
    if (typeof COLOR_NAMES === 'undefined' || !COLOR_NAMES[colorCode]) {
        return '알 수 없음';
    }
    return COLOR_NAMES[colorCode];
}

// 색상에 할당된 지역 목록 가져오기
function getRegionsByColor(colorCode) {
    if (typeof COLOR_REGION_MAP === 'undefined' || !COLOR_REGION_MAP[colorCode]) {
        return [];
    }
    return COLOR_REGION_MAP[colorCode];
}

// 지역명으로 색상 가져오기
function getColorByRegion(regionName) {
    if (typeof REGION_COLOR_MAP === 'undefined') {
        return null;
    }
    return REGION_COLOR_MAP[regionName] || null;
}

// 지역명으로 여행지 필터링
function filterDestinationsByRegions(destinations, regions) {
    if (!destinations || !Array.isArray(destinations)) {
        return [];
    }
    if (!regions || !Array.isArray(regions) || regions.length === 0) {
        return [];
    }
    
    return destinations.filter(dest => {
        if (!dest || !dest.name) return false;
        return regions.some(region => dest.name.includes(region));
    });
}

// 스크롤을 맨 위로
function scrollToTop(smooth = true) {
    if (smooth) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        window.scrollTo(0, 0);
    }
}

// 요소가 화면에 보이는지 확인
function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// 복사
function copyToClipboard(text) {
    if (navigator.clipboard) {
        return navigator.clipboard.writeText(text);
    } else {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        return Promise.resolve();
    }
}
