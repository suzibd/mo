// Application Initialization

// 앱 초기화
function initApp() {
    console.log('Initializing Travel Planner App...');

    // 더미 데이터 로드
    loadDummyData();

    // 네비게이션 렌더링
    renderNavigation();

    // 라우트 등록
    registerRoutes();

    // 라우터 초기화
    router.init();

    // 전역 에러 핸들러
    window.addEventListener('error', (e) => {
        console.error('Global error:', e.error);
        toast.error('오류가 발생했습니다. 페이지를 새로고침해주세요.');
    });

    // 전역 unhandledrejection 핸들러
    window.addEventListener('unhandledrejection', (e) => {
        console.error('Unhandled promise rejection:', e.reason);
        toast.error('요청 처리 중 오류가 발생했습니다.');
    });

    console.log('App initialized successfully!');

    // 통계 로그 (개발용)
    const stats = storage.getStats();
    console.log('App Statistics:', stats);
}

// 라우트 등록
function registerRoutes() {
    // 홈 페이지
    router.register('/', () => {
        renderHomePage();
        scrollToTop(false);
    });

    // 검색 페이지
    router.register('/search', (params) => {
        renderSearchPage(params);
        scrollToTop(false);
    });

    // 여행지 상세
    router.register('/destination/:id', (params) => {
        renderDestinationPage(params);
        scrollToTop(false);
    });

    // 여행 계획
    router.register('/planner', () => {
        renderPlannerPage();
        scrollToTop(false);
    });

    // 후기
    router.register('/reviews', (params) => {
        renderReviewPage(params);
        scrollToTop(false);
    });

    // 예약
    router.register('/reservations', () => {
        renderReservationPage();
        scrollToTop(false);
    });
}

// DOM 로드 완료 시 앱 초기화
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// 유틸리티 함수: 페이지 새로고침 없이 데이터 리셋
window.resetAppData = function() {
    if (confirm('모든 데이터를 초기화하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) {
        storage.reset();
        loadDummyData();
        toast.success('데이터가 초기화되었습니다');
        router.navigate('/');
    }
};

// 유틸리티 함수: 데이터 내보내기
window.exportAppData = function() {
    storage.exportData();
    toast.success('데이터를 내보냈습니다');
};

// 디버그 정보 (개발용)
window.appDebug = {
    storage: storage,
    router: router,
    stats: () => storage.getStats(),
    reset: () => window.resetAppData(),
    export: () => window.exportAppData()
};

console.log('Debug commands available via window.appDebug');
