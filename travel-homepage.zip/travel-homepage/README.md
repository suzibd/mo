# 여행 플래너 - Travel Homepage

순수 HTML/CSS/JavaScript로 구현한 SPA(Single Page Application) 여행 플래너입니다.

## 주요 기능

- **여행지 검색 및 추천**: 8개의 한국 여행지 더미 데이터 포함
- **여행 계획 관리**: 일정 생성, 수정, 삭제
- **여행 후기 시스템**: 후기 작성 및 공유
- **반응형 디자인**: 모바일, 태블릿, 데스크톱 지원

## 기술 스택

- HTML5
- CSS3 (CSS Variables, Flexbox, Grid)
- Vanilla JavaScript (ES6+)
- LocalStorage (데이터 저장)
- SPA (Single Page Application)

## 프로젝트 구조

```
travel-homepage/
├── index.html                 # 메인 HTML 파일
├── css/
│   ├── reset.css             # CSS 리셋
│   ├── variables.css         # 디자인 시스템 변수
│   ├── common.css            # 공통 스타일
│   ├── responsive.css        # 반응형 디자인
│   └── pages/                # 페이지별 스타일
│       ├── home.css
│       ├── search.css
│       ├── destination.css
│       ├── planner.css
│       └── review.css
├── js/
│   ├── app.js                # 앱 초기화
│   ├── router.js             # SPA 라우팅
│   ├── storage.js            # LocalStorage 관리
│   ├── data/
│   │   └── dummyData.js      # 더미 데이터
│   ├── utils/
│   │   └── helpers.js        # 헬퍼 함수
│   ├── components/
│   │   ├── navigation.js
│   │   ├── card.js
│   │   ├── modal.js
│   │   └── toast.js
│   └── pages/
│       ├── HomePage.js
│       ├── SearchPage.js
│       ├── DestinationPage.js
│       ├── PlannerPage.js
│       └── ReviewPage.js
└── assets/
    └── images/              # 이미지 (플레이스홀더)
```

## 시작하기

### 1. 파일 열기

프로젝트 디렉토리에서 `index.html` 파일을 브라우저에서 엽니다.

```bash
cd travel-homepage
# 브라우저에서 index.html 파일 열기
```

또는 로컬 서버를 사용할 수 있습니다:

```bash
# Python 3
python -m http.server 8000

# Node.js (http-server)
npx http-server -p 8000
```

브라우저에서 `http://localhost:8000` 접속

### 2. 더미 데이터

첫 방문 시 자동으로 다음 데이터가 로드됩니다:
- 여행지 8개 (제주도, 부산, 서울, 강릉, 전주, 경주, 속초, 여수)
- 샘플 여행 계획 2개
- 샘플 후기 5개

### 3. 기능 사용

#### 여행지 검색
- 네비게이션 바의 검색 기능 사용
- 카테고리, 계절, 예산으로 필터링
- 인기순, 평점순, 가격순으로 정렬

#### 여행 계획
- "내 계획" 페이지에서 새 계획 만들기
- 여행지, 날짜, 예산, 인원 설정
- 계획 상세보기 및 삭제

#### 여행 후기
- "후기" 페이지에서 후기 작성
- 별점, 제목, 내용, 태그 입력
- 도움이 되는 후기에 "도움이 돼요" 표시

## 주요 특징

### SPA 라우팅
- History API를 사용한 클라이언트 사이드 라우팅
- 동적 라우트 지원 (`/destination/:id`)
- 뒤로/앞으로 가기 지원

### LocalStorage 관리
- 자동 데이터 저장 및 로드
- CRUD 작업 지원
- 검색 및 필터링 기능

### 반응형 디자인
- 모바일 우선 설계
- 브레이크포인트: 768px (태블릿), 1024px (데스크톱)
- 햄버거 메뉴 (모바일)

### 접근성
- ARIA 레이블 지원
- 키보드 네비게이션
- 시맨틱 HTML

## 디버그 명령어

브라우저 콘솔에서 사용 가능:

```javascript
// 앱 통계 확인
appDebug.stats()

// 데이터 초기화
appDebug.reset()

// 데이터 내보내기
appDebug.export()

// 스토리지 직접 접근
appDebug.storage.get('destinations')
```

## 브라우저 호환성

- Chrome (최신)
- Firefox (최신)
- Safari (최신)
- Edge (최신)

## 라이선스

MIT License

## 개발자

Claude Sonnet 4.5와 함께 개발되었습니다.

## 추가 개선 사항 (향후)

- [ ] 이미지 업로드 기능
- [ ] 지도 통합 (Kakao Maps API)
- [ ] PWA 지원 (오프라인 모드)
- [ ] 다크 모드 토글
- [ ] 데이터 가져오기/내보내기 UI
- [ ] 소셜 공유 기능
- [ ] 여행 계획 일정 상세 편집
- [ ] 예산 추적 차트
